# Loom full experimental package

- Loom-systems.pdf is the complete current experimental report, including tables.
- Loom-All-Figures.pdf collects Figures 1–8 and all 12 appendix figures. The two assets for Figure 4 are combined on one page. The nine scenario pages retain their SIMULATE labels.
- figures/ contains the 21 original figure PDFs. main.tex, body.tex, sections/, and references.bib are the report sources. README.md documents the original build and experiment scripts in model/.
- figure_sources/ adds the archived feature-replay, placement diagnostic, communication and scaling scripts and available inputs. The archived communication and scaling scripts format supplied plot images. The placement script exports the chart as PNG.
- appendix-redraw/ contains the standalone appendix plotting toolkit. Run python appendix-redraw/redraw.py to regenerate its figures without overwriting the originals.
- Fig. 2 (tradeoff.pdf) has its original artwork but its original plotting script was unavailable. The heterophily plot retains the original artwork and includes a reconstruction script under appendix-redraw/.

# Loom systems evaluation

Main evaluation (pp. 1–6), measured details (pp. 7–10) and architecture scenarios (pp. 11–14).
The top-right SIMULATE header marks pages containing scenarios. Chart colors identify methods. The prior architecture outlook is a separate edition.

Fig. 1 and Table I join the two Plate policies on request, simulation ID and split. model/measured.py uses the bundled 2,000 latency records for 1,000 matched requests. Per-request savings exclude startup; stream time and serial throughput include it. Table III uses the archived GPU timers, kernel trace and equivalence records. Table IV selects speed and accuracy leaders in each matched comparison. All GraphLand gaps use the best non-Loom mean separately by column.

## Numeric provenance

The previous atlas input is frozen in model/atlas_input.csv. model/values.csv gives per-record provenance for Figs. S1–S7. model/figure_provenance.csv counts input records, including components, normalized values and synthetic replicates. These counts are not independent experiments. Fig. S3's seven arxiv/Loom lifetime totals are derived from archived components. Its normalized curves use scenario denominators. The S7 ledger repeats fixed controls at multiple budgets; the plot displays each fixed control once. Figs. S2 and S6 have only simulated numeric outcomes. Other figures combine archived and simulated inputs.

Fig. S6 and the Products comparison use the same central scenario. model/refresh_replay.csv supplies measured access counters; model/products_scenarios.csv gives the assumptions, work shares and hypothetical milliseconds for each pool, fraction, seed and policy. Uniform 20% and 50% extrapolate beyond the measured sweep. The modeled P95 is a target, not a sampled quantile. model/gpu_targets.csv compares modeled additional fusion to the fastest observed cached execution. The Roman Empire table instead solves the latency ceiling to tie measured external methods at fixed request counts. No additional GPU experiments were performed.

## Rebuild

The supplied vector figures are ready to compile. With MiKTeX or TeX Live:

    pdflatex -jobname=Loom-systems main.tex
    bibtex Loom-systems
    pdflatex -jobname=Loom-systems main.tex
    pdflatex -jobname=Loom-systems main.tex

To regenerate the scenario tables and seven figures, use Python with pandas, NumPy, Matplotlib, PyMuPDF and Times New Roman, from the model directory:

    python comparisons.py
    python measured.py
    python paired_cases.py
    python scenarios.py
    python -c "from front import render_front; import redesign as r; render_front(); r.payback(); r.gpu(); r.scaling(); r.updates(); import sensitivity"

The plate stream, phase timing, memory and accuracy tables retain the previous reading edition's numeric entries. The source paths in the values ledger identify upstream data files. Selected upstream CSVs are bundled in archive_inputs for offline inspection.

Fig. 8 joins the two Plate policies by mesh ID, scored-node count and seed in archive_inputs/plate_cases. The whiskers are seed ranges, not uncertainty intervals. The validation-selected epochs differ by policy. The per-mesh ratios and Roman lifetime estimates can both be regenerated with model/paired_cases.py. Roman estimates assume one build per stream and constant average forward time. The LRIM ratio rows exponentiate differences of reported mean log10 MSE. The lower S6 bar row subtracts the common 55 ms forward budget. Ochre multipliers beneath the maintenance bars divide the best external median by Loom's central median at that update fraction. The scenario coefficients and archived measurement values are unchanged.

## Paired dynamic benchmark and lifecycle outlook

Fig. 4(c,d) on page 4 and Fig. 9 on page 10 show CPU measurements on the complete Roman Empire graph and archived split-0 checkpoint. The two streams contain 32 operation batches and 48 degree/batch-size batches. Each batch is consumed by the direct patch adapter and ElectricSQL D2TS 0.1.8, a general differential-dataflow engine (https://github.com/electric-sql/d2ts). D2TS incrementally joins edges to both endpoint degrees. Both paths materialize sparse patches, refresh the feature cache and execute the same Loom network. The complete independent recomputation is outside the timer. Files under model/dynamic include raw wall times, exact batch edits, model and environment metadata, the driver, the two adapters and the npm lockfile. The two streams start afresh; samples within a stream are successive edits, not independent training runs.

To rerun the CPU measurement, install the pinned Node dependency with `npm ci --prefix model/dynamic` from this source directory. Run `python model/dynamic/replay.py` and `python model/dynamic/replay.py --sweep` in a PyTorch + PyG environment. The script locates the surrounding Loom project by default. For an extracted bundle, set LOOM_PROJECT to the original project containing scripts/profile_loom_vldb_inference.py, src/gcm, external/pytorch_geometric, and the archived Roman Empire checkpoint and mapping. The project's read_workload loader needs the original Roman Empire split-0 NPZ in the configured GraphAtlas data directory. No CUDA execution is used in this benchmark.

Page 14 joins build, first forward, steady full-forward latency, peak allocation and request count on the same 2.10M-node synthetic graph. Raw archived component measurements for Loom and SGFormer are in archive_inputs/synthetic_2097152_*.json. Products uses its own two measured CPU layout stages; the payback table solves for the required saving on that real graph. The target tables now follow their workloads: Laplace on page 11, ogbn-arxiv on page 12, and conditional update budgets on page 13. Fig. S9 follows the GPU comparison on page 12. Fig. S8 shares the four-column grid of Fig. S5 on page 14. Supplementary figure identifiers are retained from the previous edition. Fractions used as Laplace resource budgets are relative to external measurements still to be collected. The package does not contain measured external Laplace timings under this protocol. For the new plots and tables, run `python model/lifetime_updates.py` using the included CSV and JSON files, then rebuild the PDF. Numeric outputs are model/large_lifecycle.csv, model/joint_targets.csv and model/dynamic_budget.csv.

## Versioned reads
Page 10 also reports a CPU operator experiment over 32 successive versions. Run model/versioned_reads.py with data/graph_bootstrap_20261025/roman-empire/graph.npz from the project, using SciPy 1.13.1, python-graphblas 2026.11.0 and SuiteSparse:GraphBLAS 10.5.2. Run model/version_summary.py to typeset the table from the archived per-read timings. One-read totals charge the first measured read of each version; four-read totals charge all 128 reads. Retained reads return fresh dense copies. The setup and publication times repeated in the CSV are charged once per store and once per version, respectively.

"""Reconstruction from the published vector markers and interval endpoints."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

root = Path(__file__).resolve().parents[1]
data = pd.read_csv(root / "data/heterophily_vector_values.csv")
labels = data.sort_values("row").drop_duplicates("row")
fig, axes = plt.subplots(1, 5, sharey=True, figsize=(6.52,3.72))
fig.subplots_adjust(left=.105,right=.993,bottom=.085,top=.955,wspace=.19)
for i, (ax, (name, group)) in enumerate(zip(axes, data.groupby("dataset",sort=False))):
    ax.set_axisbelow(True)
    ax.grid(color="#e1e6e9",linewidth=.36)
    for r in group.itertuples():
        color = "#bf2f35" if r.method=="Loom" else plt.cm.viridis_r(.12+.72*(r.score_pct-group.score_pct.min())/(group.score_pct.max()-group.score_pct.min()))
        if pd.notna(r.interval_low):
            ax.hlines(r.row,r.interval_low,r.interval_high,color=color,lw=.55)
            ax.plot([r.interval_low,r.interval_high],[r.row,r.row],"|",ms=2,color=color)
        ax.plot(r.score_pct,r.row,marker="^" if r.method=="Loom" else "D",ms=3.1,ls="",mec=color,mfc=color if r.method=="Loom" else "white",mew=.65)
    ax.axvline(group.loc[group.method=="Loom","score_pct"].iloc[0],color="#bf2f35",ls="--",lw=.6,alpha=.5)
    ax.set_title(name,fontsize=7,pad=2)
    ax.set_xlabel("Accuracy (%)" if i<2 else "ROC-AUC (%)",fontsize=6.5,labelpad=1)
    ax.set_xticks([[50,70,90],[35,45,55],[50,70,90],[65,75,85],[55,65,75]][i])
    ax.set_yticks(labels.row,labels.method)
    ax.tick_params(labelsize=6.5,length=1.8,pad=1)
    ax.spines[["left","right"]].set_visible(False)
axes[0].set_ylim(32.8,-.8)
fig.savefig(root / "figures/hetero.pdf")
plt.close(fig)

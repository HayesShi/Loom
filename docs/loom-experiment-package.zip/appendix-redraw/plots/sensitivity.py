from front import *
plt.rcParams.update(front_style)
sens=['Identity','Rabbit','GOrder','METIS-1024','Gray','Loom']
f,axs=frame(7,(1,5),2.25,.72,.31,ws=.47);legend(f,sens,.9,6,True)
for i,(ax,p) in enumerate(zip(axs,['Feature width','Hidden width','Layers','Mean degree','Refinement passes'])):
    name(ax,i,['Feature width','Hidden width','Layer count','Mean degree','Refinement'][i]);t=sub(7,p);xs=sorted(t.x.unique())
    for j,m in enumerate(sens):
        a=t[t.method==m]
        if i<3:
            bp=ax.boxplot([a[a.x==x].value for x in xs],positions=np.arange(len(xs))+(j-2.5)*.145,widths=.118,manage_ticks=False,patch_artist=True,showfliers=False,boxprops={'linewidth':.42,'facecolor':pale(m),'edgecolor':color[m]},medianprops={'linewidth':.7,'color':color[m]},whiskerprops={'linewidth':.45,'color':color[m]},capprops={'linewidth':.42,'color':color[m]})
        else:
            a=a.sort_values('x')
            if i==4 and m!='Loom':
                assert a.value.nunique()==1
                ax.scatter(-1.25+.09*j,a.value.iloc[0],color=color[m],marker=markers[j%7],s=9,zorder=3)
            else:
                ax.plot(a.x,a.value,color=color[m],lw=1,marker=markers[j%7],ms=3,mfc=color[m],mew=.72)
    if i<3:ax.set_xticks(range(len(xs)),[str(int(x)) for x in xs])
    elif i==3:ax.set_xscale('log',base=2);ax.set_xticks([2,8,32,64],['2','8','32','64'])
    else:ax.set_xticks([-1.1,*xs],['Fix.',*[str(int(x)) for x in xs]]);ax.set_xlabel('Pass budget')
    if i<4:ax.set_ylim(.67,2.35)
    if i==0:ax.set_ylabel('Speedup (×)')
    if i==4:ax.set_ylabel('Mean bits',labelpad=1)
note(f,'Boxes show quartiles across 12 synthetic trials per cell. Fixed layouts in (e) appear once at left; the curve follows Loom across pass budgets.')
save(f,7)

from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]

plt.rcParams.update({"font.family":"Times New Roman", "font.size":7.1, "axes.labelpad":1.6,
                     "axes.linewidth":.5, "axes.spines.top":False, "axes.spines.right":False,
                     "xtick.major.size":2.5, "ytick.major.size":2.5, "pdf.fonttype":42})
fig,ax=plt.subplots(figsize=(3.44,1.52))
fig.subplots_adjust(left=.12,right=.98,bottom=.24,top=.76)
curves=pd.read_csv(root/"data/roman_lifetime.csv")
for (name, series),color,style in zip(curves.groupby("comparator",sort=False),
        ["#375f83","#789f9a","#786e8d","#9c4a24","#547563","#4c5158"],["-","--","-.", "-", "--",":"]):
    q=series.requests
    ratio=series.projected_speedup
    ax.plot(q,ratio,label=name,color=color,ls=style,lw=1.35 if name=="GraphGPS" else .9)
ax.axhline(1,color=".45",ls=":",lw=.55)
ax.set(xscale="log",xlim=(1,10000),ylim=(0,3.35),yticks=[0,1,2,3],
       xlabel="Requests sharing one layout",ylabel="Baseline / Loom (×)")
ax.legend(loc="lower center",bbox_to_anchor=(.52,1.01),ncol=3,frameon=False,fontsize=6.4,
          handlelength=1.6,columnspacing=.72,handletextpad=.32,labelspacing=.08)
fig.savefig(root/"figures/roman_lifetime.pdf")
plt.close(fig)

"""Render the seven figures from values.csv; does not generate observations."""
from pathlib import Path
import string
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.colors import to_rgb, ListedColormap
from matplotlib.lines import Line2D
OUT=Path(__file__).resolve().parent
layouts=list(pd.read_csv(OUT.parent/'data'/'values.csv').query('figure==1').method.unique())
graphs=['Plate','arxiv','Products','Reddit','Wikipedia','Roman']

d=pd.read_csv(OUT.parent/'data'/'values.csv')
front_style=({'font.family':'Times New Roman','font.size':7,'axes.labelsize':7.4,'axes.titlesize':8,'axes.linewidth':.5,'axes.spines.top':False,'axes.spines.right':False,'xtick.major.size':2,'ytick.major.size':2,'xtick.major.pad':1.5,'ytick.major.pad':1.5,'pdf.fonttype':42,'svg.fonttype':'none','mathtext.fontset':'stix','hatch.linewidth':.3})
palette=['#858585','#C7C7C7','#0072B2','#468EBB','#84B7D4','#685C83','#A59BB3','#547681','#30606F','#AD5F95','#CC79A7','#58B59B','#009E73','#AB8F9D','#986D88','#77536B','#62405C','#493148','#56B4E9','#168898','#D55E00']
color=dict(zip(layouts,palette))
updates=['Full re-aggregation','Affected rows','Incremental','Loom']
color.update(dict(zip(updates,['#737373','#0757A6','#16877B','#D55E00'])))
markers=['o','s','^','D','v','P','X']
titles=['Layout quality and compilation cost','Inference performance of layout strategies','When does compilation pay off?','GPU execution and layout interaction','Scalability and memory capacity','Feature-update sensitivity on ogbn-products','Sensitivity to model, graph, and compiler settings']
def pale(m):
    return .52+.48*np.array(to_rgb(color[m]))
def sub(f,p):
    return d[(d.figure==f)&(d.panel==p)]
def frame(n,shape,height,top,bottom,hs=.68,ws=.28):
    fig,axes=plt.subplots(*shape,figsize=(7.12,height),squeeze=False)
    fig.subplots_adjust(left=.073,right=.989,bottom=bottom,top=top,hspace=hs,wspace=ws)
    fig.text(.013,.986,f'Fig. S{n}.  {titles[n-1]}',va='top',weight='bold',fontsize=9.1)
    for ax in axes.flat:
        ax.set_axisbelow(True);ax.grid(axis='y',lw=.38,color='#dbdcde')
    return fig,axes.flat
def legend(fig,methods,y,cols,line=False):
    handles=[Line2D([],[],color=color[m],marker=markers[i%7],ms=3,lw=.85) if line else Patch(facecolor=pale(m),edgecolor=color[m],linewidth=.55,hatch=['','/','', '\\',''][i%5] if len(methods)==21 else None) for i,m in enumerate(methods)]
    fig.legend(handles,methods,loc='upper center',bbox_to_anchor=(.5,y),ncol=cols,frameon=False,fontsize=6.8,columnspacing=.85,handlelength=1.55,handletextpad=.32,labelspacing=.24)
def name(ax,i,label):
    ax.set_title(f'({string.ascii_lowercase[i]})  {label}',loc='left',pad=2,fontweight='bold')
def grouped(ax,tab,groups,methods):
    for j,m in enumerate(methods):
        a=tab[tab.method==m].set_index('dataset').reindex(groups)
        x=np.arange(len(groups))+(j-(len(methods)-1)/2)*.93/len(methods)
        ax.bar(x,a.value,width=.90/len(methods),color=pale(m),edgecolor=color[m],lw=.48,hatch=['','/','','\\',''][j%5] if len(methods)==21 else None)
        mask=(a.status=='measured')&a.value.notna()
        ax.scatter(x[mask],a.value[mask],marker='.',s=6,c='#161616',zorder=4)
        na=a.status=='unavailable'
        if na.any():ax.scatter(x[na],np.full(na.sum(),.025),transform=ax.get_xaxis_transform(),marker='x',linewidths=.45,s=4,c='#333333',zorder=5)
    ax.set_xticks(range(len(groups)),groups);ax.set_xlim(-.54,len(groups)-.46)
def note(fig,s):
    fig.text(.013,.017,s,fontsize=7,va='bottom')
def save(fig,n):
    fig.savefig(OUT.parent/'figures'/f'f{n}.pdf')
    plt.close(fig)
def label_comparisons(ax,table,panel):
    selected=['Identity','RCM','GOrder','METIS-128','Loom']
    labels=[]
    for m in selected:
        j=layouts.index(m)
        for gi,g in enumerate(graphs):
            block=table[table.dataset==g].set_index('method').reindex(layouts)
            v=block.value.iloc[j]
            if not np.isfinite(v):continue
            xpos=gi+(j-10)*.93/21
            label=f'{v:.2g}' if panel=='Compile (s)' else (f'{v:.2f}' if panel in ['DGL','PyG','Graphiler','Optimized kernel'] else f'{v:.1f}'.removesuffix('.0'))
            if panel=='Compile (s)':
                label=f'{v:.3f}' if v<.1 else (f'{v:.2f}' if v<1 else (f'{v:.1f}' if v<10 else f'{v:.0f}'))
            # Set text above the adjacent thin bars; a hairline locates its bar.
            ymax=block.value.iloc[max(0,j-1):min(21,j+2)].max()
            ax.annotate('',xy=(xpos,v),xytext=(xpos,ymax),arrowprops=dict(arrowstyle='-',lw=.29,color='#4d5154',shrinkA=0,shrinkB=0))
            tag=ax.annotate(label,(xpos,ymax),xytext=(0,1.8),textcoords='offset points',rotation=90,fontsize=5.5,
                        color='#99491f' if m=='Loom' else '#2a2e30',fontweight='bold' if m=='Loom' else 'normal',va='bottom',ha='center')
            labels.append(tag)
    # Adjacent dataset groups have two edge labels. Stagger only actual collisions.
    fig=ax.figure
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    boxes=[]
    for tag in sorted(labels,key=lambda tag:tag.xy[0]):
        box=tag.get_window_extent(renderer).expanded(1.06,1.02)
        for earlier in boxes:
            if box.overlaps(earlier):
                dy=earlier.y1-box.y0+1.2
                offset=tag.get_position()[1]+dy*72/fig.dpi
                tag.set_position((0,offset))
                box=tag.get_window_extent(renderer).expanded(1.06,1.02)
        boxes.append(box)
@plt.rc_context(front_style)
def render_front():
    for n,panels in [(1,['Compile (s)','Mean distance','P95 distance','Direct pairs (%)']),(2,['DGL','PyG','Graphiler','Optimized kernel'])]:
        f,axs=frame(n,(2,2),3.54,.77,.14,.53,.17)
        legend(f,layouts,.935,7)
        for i,(ax,p) in enumerate(zip(axs,panels)):
            grouped(ax,sub(n,p),graphs,layouts);name(ax,i,p)
            if n==1 and i==0:ax.set_yscale('log')
            if n==2:
                ax.axhline(1,c='.32',lw=.6,ls='--');ax.set_ylim(0,2.45)
                if i%2==0:ax.set_ylabel('Speedup (×)')
            if n==1:
                high=sub(n,p).value.max()
                if i==0:ax.set_ylim(.003,high*75)
                else:ax.set_ylim(0,high*1.57)
            label_comparisons(ax,sub(n,p),p)
        f.text(.013,.061,'Bar labels: Identity, RCM, GOrder, METIS-128 and Loom, in layout order.',fontsize=6.9)
        note(f,'Dots = archived; crosses = more partitions than vertices. Distances count differing bits; direct pairs have distance one.' if n==1 else 'Identity time / layout time within each backend. Crosses = infeasible partitions; remaining cells assume operator compatibility.')
        save(f,n)

from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import NullLocator
import redesign as atlas

root = Path(__file__).resolve().parents[1]
data = root / "data"
archive = data
figures = root / "figures"

blue, orange, teal, grey, plum = "#315D83", "#A44C30", "#38786A", "#636971", "#756080"
sweep=pd.read_csv(data/"sweep_trials.csv")
def render_degree_sweep():
    width, height = 264.96, 82.80
    fig = plt.figure(figsize=(width/72,height/72))
    axes = [fig.add_axes([x/width,20.5/height,99/width,45/height]) for x in (27,161)]
    modes = [("direct","#e4bb9d","#985023","//"),("d2ts","#a4bccb","#4e6e83","")]
    fig.legend([Patch(facecolor=fill,edgecolor=edge,hatch=hatch,lw=.55) for _,fill,edge,hatch in modes],
               ["Direct adapter","D2TS"],loc="upper center",bbox_to_anchor=(.52,1.025),
               frameon=False,ncol=2,fontsize=7,handlelength=1.7,handletextpad=.35,columnspacing=1.5,borderaxespad=0)
    for i,(ax,count) in enumerate(zip(axes,[8,128])):
        ax.grid(axis="y",lw=.35,color="#dde0e2")
        ax.set_axisbelow(True)
        for j,(mode,fill,edge,hatch) in enumerate(modes):
            groups=sweep[(sweep.edge_batch==count)&(sweep["mode"]==mode)].groupby("kind")
            med=groups.maintenance_ms.median().reindex(["Low","Uniform","High"])
            bars=ax.bar(np.arange(3)+(j-.5)*.36,med,width=.31,color=fill,edgecolor=edge,hatch=hatch,lw=.55)
            for bar,m in zip(bars,med):
                ax.annotate(f"{m:.1f}",(bar.get_x()+bar.get_width()/2,m),xytext=((-1.3,1.2) if j==0 else (1.3,1.2)),textcoords="offset points",ha="center",fontsize=5.8,color=edge)
        ax.set_xticks(range(3),["Low","Unif.","High"])
        ax.set_ylabel("P50 (ms)",fontsize=7)
        ax.set_xlabel(["(a)  Eight edge edits","(b)  128 edge edits"][i],labelpad=1,fontsize=7.2)
        ax.set(ylim=(0,(5,58)[i]),yticks=([0,2,4],[0,20,40])[i])
    fig.savefig(figures/"dynamic_degree.pdf")
    plt.close(fig)

render_degree_sweep()

def load_case(name):
    return json.loads((archive/f"synthetic_2097152_{name}.json").read_text())
l,s=map(load_case,["loom","sgformer"])
def components(d):
    return np.array([d["compile_ms"]/1000,d["first_full_inference_ms"]/1000,
                     d["end_to_end"]["median_ms"]/1000,d["end_to_end"]["peak_allocated_MiB"]])
lc,sc=map(components,[l,s])
cases_gpu={"SGFormer":sc,"Loom eager":lc}
for k in [1.5,2,5]:
    cases_gpu[f"Forward / {k:g}"]=lc/[1,k,k,1]
cases_gpu["Joint target"]=np.array([3,lc[1]/5,lc[2]/5,4096])
def cost(c,q):
    return c[0]+c[1]+(q-1)*c[2]
def crossing(c):
    if cost(c,1)<cost(sc,1): return 1
    if c[2]>=sc[2]: return None
    return 2+int(np.floor((cost(c,1)-cost(sc,1))/(sc[2]-c[2])))
# Use the same column positions, marker weights, inset rules and type as Fig. S5.
f=atlas.start(8,"Cost over the lifetime of one layout at 2.10M nodes",1.64)
axes=[atlas.panel(f,[.061+j*.246,.27,.197,.42],title) for j,title in enumerate(
    ["(a)  Total time (s)","(b)  Time / request (s)","(c)  Lifetime speedup"])]
q=np.unique(np.r_[np.geomspace(1,3000,220).astype(int),10,100,1000])
styles=[("SGFormer",atlas.STYLES["Identity"][0],"o","-"),("Loom eager",atlas.ACCENT,"D","-"),
        ("Forward / 2","#536e88","s","--"),("Joint target","#38786A","^","-.")]
for name,col,marker,ls in styles:
    c=cases_gpu[name]
    total=cost(c,q)
    for ax,ys in zip(axes,[total,total/q,cost(sc,q)/total]):
        ax.plot(q,ys,color=col,marker=marker,ls=ls,mfc=col if name=="Loom eager" else "white",
                ms=2.8,mew=.55,lw=1.1,markevery=np.searchsorted(q,[1,10,100,1000,3000]).tolist())
for ax in axes:
    ax.set(xscale="log",xticks=[1,10,100,1000],xticklabels=["1","10","100","1k"],xlabel="Requests per layout")
for ax,ticks in zip(axes[:2],[[10,100,1000,10000],[2,10,100]]):
    ax.set_yscale("log");ax.set_yticks(ticks,[f"{v:,}" for v in ticks]);ax.yaxis.set_minor_locator(NullLocator())
axes[2].set(ylim=(0,3.9),yticks=[0,1,2,3])
cross=crossing(cases_gpu["Forward / 2"])
axes[2].annotate(f"Q = {cross}",(cross,1),xytext=(-7,10),textcoords="offset points",
                 fontsize=6.3,color="#42576d",arrowprops=dict(arrowstyle="-",color="#536e88",lw=.45))
handles=[Line2D([],[],color=c,marker=m,ls=l,ms=3,mfc=c if n=="Loom eager" else "white",lw=1)
         for n,c,m,l in styles]
f.legend(handles,[n for n,*_ in styles],loc="upper center",bbox_to_anchor=(.46,.88),
         ncol=4,fontsize=6.8,handlelength=2,columnspacing=1.1,frameon=False,borderaxespad=0)
labels=["SGFormer","Eager","Fwd / 2","Joint"]
cells=[[f"{cases_gpu[name][3]/1024:.2f}",("ref." if name=="SGFormer" else
        ("∞" if crossing(cases_gpu[name]) is None else str(crossing(cases_gpu[name]))))] for name,*_ in styles]
atlas.table(f,[.762,.27,.226,.42],labels,[("Peak / crossover",2)],["GiB","Q*"],cells,[1.35,1,1],
            first_header="Path")
atlas.caption(f,"Solid curves use measured components. Dashed scenarios change forward time; the joint target also changes build and peak memory.",.028)
f.savefig(figures/"large_lifecycle.pdf");plt.close(f)

d=pd.read_csv(data/"arxiv_models.csv")
cold=180+650+100+4
warm_target_ms=3.30
f=plt.figure(figsize=(3.44,1.52))
axes=[atlas.panel(f,[.102,.24,.362,.48],"(a)  Phase ceiling"),
      atlas.panel(f,[.605,.24,.365,.48],"(b)  Reuse budget")]
k=np.geomspace(1,256,100)
for j,col,ls,mk in [(1,grey,":","o"),(4,blue,"--","s"),(16,atlas.ACCENT,"-","D")]:
    axes[0].loglog(k,541.268/k+(579.08-541.268)/j,color=col,ls=ls,marker=mk,markevery=[0,49,99],ms=2.5,lw=1,mfc="white")
axes[0].axhline(3.3,color=teal,ls="--",lw=.8)
axes[0].text(.02,.08,"3.30 ms goal",transform=axes[0].transAxes,color=teal,fontsize=7)
axes[0].set(xlabel="ARCO acceleration (×)",ylabel="Warm ms",xticks=[1,4,16,64,256],
            xticklabels=["1","4","16","64","256"])

q=np.unique(np.geomspace(1,10000,200).astype(int))
sage=d[(d.model=="sage")&(d.seed==0)].iloc[0]
sg_cost=(sage.host_input_and_artifact_load_ms+sage.device_and_graph_setup_ms+
         sage.first_forward_ms+(q-1)*sage.warm_forward_median_ms)
for setup,col,style in [(cold,orange,"-"),(cold-180+9248.8628,blue,"--")]:
    axes[1].semilogx(q,sg_cost/(setup+(q-1)*warm_target_ms),color=col,ls=style,lw=1.1)
axes[1].axhline(1,color=grey,lw=.6)
axes[1].set(xlabel="Requests per layout",ylabel="GraphSAGE / goal",
            xticks=[1,10,100,1000,10000],xticklabels=["1","10","100","1k","10k"])

f.text(.11,.945,"Other work",fontsize=6.5)
for x,lab,col in [(.31,"1×",grey),(.37,"4×",blue),(.43,"16×",atlas.ACCENT)]:
    f.text(x,.945,lab,color=col,fontsize=6.5)
f.text(.595,.945,"Build",fontsize=6.5)
f.text(.695,.945,"0.18 s",color=orange,fontsize=6.5)
f.text(.83,.945,"9.25 s",color=blue,fontsize=6.5)
f.savefig(figures/"joint_frontiers.pdf");plt.close(f)

"""Render all appendix plots and rebuild the figure-only PDF."""
from pathlib import Path
import subprocess
import sys
from assemble import assemble

root = Path(__file__).resolve().parent
(root/"figures").mkdir(exist_ok=True)
plots = root/"plots"
subprocess.run([sys.executable,"-c","from front import render_front; import redesign as r; render_front(); r.payback(); r.gpu(); r.scaling(); r.updates(); import sensitivity"],cwd=plots,check=True)
for script in ("system_plots.py","roman_lifetime.py","heterophily.py"):
    subprocess.run([sys.executable,str(plots/script)],check=True)
assemble()

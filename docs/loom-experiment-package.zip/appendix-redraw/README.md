# Loom Appendix Figures

The bundled PDF contains the original vector artwork for the 12 plots in appendices B and S of Loom-systems.pdf. PDF bookmarks identify each figure. Figures S1-S9 carry the SIMULATE page label. S2 and S6 contain simulated outcomes; the other marked figures contain scenarios, including comparisons to archived measurements. The unnumbered Roman Empire lifetime plot projects measured build and warm times across request counts.

Run from the extracted directory:

    python -m pip install numpy pandas matplotlib pypdf
    python redraw.py

Individual regenerated PDFs appear in figures/. The command also rebuilds Loom-Appendix-Figures.pdf. Use Times New Roman to match the original fonts. plots/ contains the plotting code and data/ the inputs. values.csv includes per-record provenance. The heterophilous benchmark plot in the supplied PDF is the original. Its redraw script is a reconstruction; its CSV contains the point estimates and interval endpoints recovered from the vector figure, rounded to two decimal places.

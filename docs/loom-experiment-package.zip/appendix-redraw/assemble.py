"""Collect vector figures into a bookmarked PDF; retain the page-level scenario label."""
from pathlib import Path
from io import BytesIO
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pypdf import PdfReader, PdfWriter, PageObject, Transformation

ROOT = Path(__file__).resolve().parent
ITEMS = [
    ("hetero", "Appendix B", "Heterophilous node benchmarks", False),
    ("dynamic_degree", "Fig. 9", "Roman Empire: median maintenance time by degree pool", False),
    ("f1", "Fig. S1", "Layout quality and compilation cost", True),
    ("f2", "Fig. S2", "Inference performance of layout strategies", True),
    ("f3", "Fig. S3", "Compilation cost and query payback", True),
    ("f4", "Fig. S4", "GPU execution and layout interaction", True),
    ("f5", "Fig. S5", "Scalability and memory capacity", True),
    ("f6", "Fig. S6", "Feature-update sensitivity on ogbn-products", True),
    ("f7", "Fig. S7", "Sensitivity to model, graph and compiler settings", True),
    ("large_lifecycle", "Fig. S8", "Cost over the lifetime of one layout at 2.10M nodes", True),
    ("joint_frontiers", "Fig. S9", "ogbn-arxiv: phase ceiling and reuse budget", True),
    ("roman_lifetime", "Appendix S", "Roman Empire: lifetime speedup from measured build and warm times", False),
]

def assemble():
    writer = PdfWriter()
    for index, (stem, label, title, simulated) in enumerate(ITEMS):
        chart = PdfReader(ROOT / "figures" / (stem + ".pdf")).pages[0]
        w, h = float(chart.mediabox.width), float(chart.mediabox.height)
        width = max(w + 12, 348 if stem=="roman_lifetime" else 306)
        height = h+24
        page = PageObject.create_blank_page(width=width,height=height)
        header = plt.figure(figsize=(width/72,height/72))
        embedded = stem in {"f1","f2","f3","f4","f5","f6","f7","large_lifecycle"}
        header.text(6/width,1-6/height,"Appendix S" if embedded else label+"  |  "+title,va="top",fontsize=7.2)
        raw = BytesIO()
        header.savefig(raw,format="pdf")
        plt.close(header)
        page.merge_page(PdfReader(raw).pages[0])
        page.merge_transformed_page(chart,Transformation().translate((width-w)/2,4))
        writer.add_page(page)
        writer.add_outline_item(label+" | "+title,index)
    writer.add_metadata({"/Title":"Loom Appendix Figures"})
    writer.write(ROOT / "Loom-Appendix-Figures.pdf")

if __name__=="__main__":
    assemble()

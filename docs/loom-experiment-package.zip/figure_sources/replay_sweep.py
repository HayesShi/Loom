"""Generate trace-based workload and feature-refresh comparisons for the two-column paper."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import FixedLocator,FixedFormatter,NullLocator

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/"model"
FIG=ROOT/"figures"
COL=["#CB5930","#78529A","#0757A6","#16877B"]
STYLE=["-","--","-.",":"]
MARK=["o","s","^","x"]
plt.rcParams.update({"font.family":"serif","font.serif":["Times New Roman","STIXGeneral","DejaVu Serif"],
 "font.size":8,"axes.labelsize":8.0,"xtick.labelsize":7.25,"ytick.labelsize":7.25,
 "axes.labelpad":1.0,"axes.linewidth":.52,"legend.fontsize":7.25,"hatch.linewidth":.42,
 "xtick.direction":"in","ytick.direction":"in","xtick.major.size":2.2,"ytick.major.size":2.2,"pdf.fonttype":42})
def read(n):
    with (DATA/n).open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))
def draw_refresh():
    rows=read("refresh_replay.csv")
    graphs=["roman_empire","ogbn_arxiv","ogbn_products"]
    policies=["low_degree","uniform","high_degree"]
    fig,axs=plt.subplots(2,3,figsize=(7.06,1.56),sharex="col",sharey="row")
    fig.subplots_adjust(left=.068,right=.991,top=.86,bottom=.24,hspace=.20,wspace=.12)
    for col,g in enumerate(graphs):
        for j,policy in enumerate(policies):
            sub=[r for r in rows if r["graph"]==g and r["policy"]==policy]
            counts=sorted(set(int(v["changed"]) for v in sub));n=int(sub[0]["nodes"])
            x=100*np.array(counts)/n
            for row,(num,den) in enumerate([("affected_rows","nodes"),("row_reaggregation_entries","incident_entries")]):
                vals=np.array([[(100 if row==0 else 1)*int(v[num])/max(1,int(v[den])) for v in sub if int(v["changed"])==c] for c in counts])
                low,mid,high=np.percentile(vals,[0,50,100],axis=1)
                a=axs[row,col];a.fill_between(x,low,high,color=COL[j],alpha=.17,lw=0)
                a.plot(x,mid,c=COL[j],ls=STYLE[j],marker=MARK[j],mfc="white",ms=2.1,mew=.5,markevery=1,lw=.92,clip_on=True)
                a.set(xscale="log",yscale="linear" if row==0 else "log",xlim=(.0008,12),ylim=(-1,100) if row==0 else (.85,2500))
        for row in range(2):
            h=axs[row,col];h.tick_params(pad=.6,labelsize=5.8)
            h.xaxis.set_major_locator(FixedLocator([.001,.01,.1,1,10]));h.xaxis.set_major_formatter(FixedFormatter([".001",".01",".1","1","10"]))
            ticks=[0,50,100] if row==0 else [1,10,100,1000]
            h.yaxis.set_major_locator(FixedLocator(ticks));h.yaxis.set_major_formatter(FixedFormatter([str(i) for i in ticks]))
            h.yaxis.set_minor_locator(NullLocator());h.xaxis.set_minor_locator(NullLocator())
        a=axs[1,col];a.set_xlabel("Changed vertices (%)",fontsize=6.3,labelpad=.4)
        p=a.get_position();fig.text((p.x0+p.x1)/2,.007,["(a) Roman Empire","(b) ogbn-arxiv","(c) ogbn-products"][col],ha="center",fontsize=6.9)
    axs[0,0].set_ylabel("Rows (%)",fontsize=6.4);axs[1,0].set_ylabel("Scan / delta (×)",fontsize=6.4)
    lab=["Low-degree pool","Uniform updates","High-degree pool"]
    handles=[Line2D([],[],marker=m,ls=st,color=c,lw=1.1,markerfacecolor="white",ms=3.2,label=l) for m,st,c,l in zip(MARK,STYLE,COL,lab)]
    fig.legend(handles=handles,ncol=3,fontsize=6.8,loc="upper center",bbox_to_anchor=(.5,1.025),frameon=False,markerfirst=False,handlelength=2,handletextpad=.35)
    fig.savefig(FIG/"replay_sweep.pdf");plt.close(fig)

if __name__=='__main__':
    draw_refresh()

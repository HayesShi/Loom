"""Keep the supplied 2x2 panel layout and correct its old legend wording.

The author identified "Generated" as a previous AI labeling mistake.
This script changes only that legend text; all curves, points, axes, panel
positions, and the original input image remain unchanged.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parent.parent / 'figures'
image = Image.open(root / 'author_provided_mechanism.png')
draw = ImageDraw.Draw(image)
draw.rectangle((1568, 1585, 2160, 1647), fill='white')
font = ImageFont.truetype('C:/Windows/Fonts/times.ttf', 39)
draw.text((1575, 1591), 'Shading: ±1 SD', font=font, fill='#222222')
image.save(root / 'communication_scenarios_compact.png')

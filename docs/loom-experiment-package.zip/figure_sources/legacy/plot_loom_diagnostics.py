# Style adapted from the user-selected plot_precision_from_loom.py.
# Data: the original Loom compiler/interface diagnostic means and standard deviations.
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'figures'
with (ROOT/'loom_diagnostics.csv').open(encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
plt.rcParams.update({'font.family':'Times New Roman', 'font.size':7,
    'axes.titlesize':6.0, 'xtick.labelsize':5.8, 'ytick.labelsize':6.0,
    'pdf.fonttype':42, 'ps.fonttype':42, 'svg.fonttype':'none',
    'axes.linewidth':.5, 'axes.edgecolor':'#8D8D8D',
    'xtick.major.width':.5, 'ytick.major.width':.5,
    'mathtext.fontset':'stix'})
fig = plt.figure(figsize=(52/25.4, 39/25.4))
axes = [fig.add_axes(rect) for rect in
        [[.285,.625,.32,.245],[.68,.625,.30,.245],
         [.285,.15,.32,.29],[.68,.15,.30,.29]]]
panels = [
    ('hamming', 'Hamming $\\downarrow$', 1, 1.4, [0,.7,1.4]),
    ('relabel_drift', 'Drift $\\downarrow$', 1000, 50, [0,25,50]),
    ('effective_rank', 'Rank $\\uparrow$', 1, 260, [0,125,250]),
    ('inference_latency', 'Time (ms)', 1, 2, [0,1,2])]
short = {'Independent':'Indep.', 'Per-sample XOR':'Sample XOR','Pool--broadcast':'Pool',
         '4-hub attention':'4 hubs','16-hub attention':'16 hubs','Static butterfly':'Static'}
for ax, (metric, title, scale, limit, ticks) in zip(axes, panels):
    data = [r for r in rows if r['metric'] == metric]
    names = [r['method'] for r in data]
    palette={'Reference':('#0757A6','#0757A6'),'Loom':('#0757A6','#0757A6'),
             'Fixed XOR':('#16877B','#78B7AE'),'4-hub attention':('#16877B','#78B7AE'),
             '16-hub attention':('#CB5930','#EBA17C'),'Static butterfly':('#78529A','#B29ACB')}
    edges=[palette.get(n,('#8F969E','#C3C8CE'))[0] for n in names]
    colors=[palette.get(n,('#8F969E','#C3C8CE'))[1] for n in names]
    ax.barh(range(len(data)), [float(r['mean'])*scale for r in data],
            xerr=[float(r['sd'])*scale for r in data], height=.60,
            color=colors, edgecolor=edges, linewidth=.4,
            error_kw=dict(ecolor='#252A31',elinewidth=.65,capsize=1.6,capthick=.65), zorder=3)
    ax.set_yticks(range(len(data)), [short.get(n,n) for n in names])
    if metric in ['relabel_drift','inference_latency']:
        ax.set_yticklabels([])
    ax.set_ylim(len(data)-.45,-.55)
    ax.set_xlim(0,limit); ax.set_xticks(ticks, [f'{t:g}' for t in ticks])
    ax.set_title(title, loc='left', pad=3.4)
    if metric == 'relabel_drift':
        ax.text(.98,.04,r'$10^{-3}$',transform=ax.transAxes,ha='right',va='bottom',fontsize=5.8)
    ax.tick_params(axis='y', length=0, pad=2)
    ax.tick_params(axis='x', length=2, pad=1.5)
    ax.spines[['top','right','left']].set_visible(False)
    ax.spines['bottom'].set_color('#8D8D8D')
    ax.grid(False)
    for tick, name in zip(ax.get_yticklabels(), names):
        if name in ['Reference','Loom']: tick.set_fontweight('bold')
for extension in ['pdf','svg']:
    fig.savefig(OUT / ('mechanism_diagnostics_wrap.'+extension), bbox_inches='tight', pad_inches=.01)
fig.savefig(OUT/'mechanism_diagnostics_wrap.png',dpi=400,bbox_inches='tight',pad_inches=.01)
plt.close(fig)

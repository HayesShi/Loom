"""Improve single-column typography without regenerating any plotted data.

The supplied PNGs remain the source of every curve, point, band and arrow.
Only the listed text/legend rectangles are cleared. Larger live PDF text is
then drawn in those areas. Canvas sizes and 2-by-2 arrangements are unchanged.
"""
from io import BytesIO
from pathlib import Path
import os

from PIL import Image, ImageDraw
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

ROOT = Path(__file__).resolve().parents[1] / 'figures'
FONTS = Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts'
for name, filename in [('TimesPaper', 'times.ttf'), ('TimesPaperBold', 'timesbd.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONTS / filename)))
BLUE, RED, TEAL, PURPLE = '#194287', '#b32d24', '#427d78', '#837494'


class FigureType:
    def __init__(self, source, output):
        self.image = Image.open(ROOT / source).convert('RGB')
        self.w, self.h = self.image.size
        self.draw = ImageDraw.Draw(self.image)
        self.output = ROOT / output
        self.ops = []

    def clear(self, box, color='white'):
        self.draw.rectangle(box, fill=color)

    def text(self, x, y, label, size=54, anchor='left', color='#171717', bold=False, angle=0):
        self.ops.append(('text', x, y, label, size, anchor, color, bold, angle))

    def line(self, x1, y, x2, color, dashed=False, marker=None):
        self.ops.append(('line', x1, y, x2, color, dashed, marker))

    def save(self):
        c = canvas.Canvas(str(self.output), pagesize=(self.w, self.h), initialFontName='TimesPaper')
        c.setTitle('Loom figure: original plotted evidence with enlarged typography')
        c.drawImage(ImageReader(self.image), 0, 0, self.w, self.h)
        for op in self.ops:
            if op[0] == 'text':
                _, x, y, label, size, anchor, color, bold, angle = op
                c.saveState()
                c.translate(x, self.h - y)
                c.rotate(angle)
                c.setFillColor(color)
                c.setFont('TimesPaperBold' if bold else 'TimesPaper', size)
                {'left': c.drawString, 'center': c.drawCentredString, 'right': c.drawRightString}[anchor](0, 0, label)
                c.restoreState()
            else:
                _, x1, y, x2, color, dashed, marker = op
                c.saveState()
                c.setStrokeColor(color)
                c.setFillColor(color)
                c.setLineWidth(6)
                if dashed:
                    c.setDash(20, 11)
                c.line(x1, self.h-y, x2, self.h-y)
                if marker == 'circle':
                    c.circle((x1+x2)/2, self.h-y, 10, stroke=0, fill=1)
                elif marker == 'square':
                    c.rect((x1+x2)/2-9, self.h-y-9, 18, 18, stroke=0, fill=1)
                c.restoreState()
        c.showPage()
        c.save()
        # A full-resolution preview uses the same final PDF text.
        import pymupdf
        with pymupdf.open(self.output) as doc:
            doc[0].get_pixmap().save(self.output.with_suffix('.png'))


def communication():
    f = FigureType('communication_scenarios_compact.png', 'communication_scenarios_readable.pdf')
    # Outside the axes: leave spines, tick marks, all curves and all bands intact.
    for box in [(0,0,180,625), (1434,0,1613,625), (0,817,180,1429),
                (1434,817,1613,1429), (180,628,1380,760), (1615,628,2730,760),
                (180,1444,1380,1570), (1615,1444,2730,1570)]:
        f.clear(box)
    for xs in [[216,437,658,879,1101], [1652,1873,2094,2315,2535]]:
        for x, label in zip(xs, ['0','0.25','0.5','0.75','1']):
            f.text(x, 669, label, anchor='center')
    for x, labels, ys in [
        (180,['1','0.75','0.5','0.25','0'],[51,191,329,469,607]),
        (1614,['1.45','1.3','1.15','1'],[41,214,388,561]),
        (180,['0.5','0.1','0.05','0.01','0.005'],[866,1040,1115,1290,1365]),
        (1614,['0.5','0.1','0.05','0.01','0.005'],[866,1040,1115,1290,1365])]:
        for label, y in zip(labels, ys):
            f.text(x, y+17, label, anchor='right')
    for xs, labels in [([217,367,518,668,818,968,1119],['1','2','4','8','16','32','64']),
                       ([1655,1835,2015,2195,2375,2554],['1','2','4','8','16','32'])]:
        for x, label in zip(xs, labels):
            f.text(x,1488,label,anchor='center')
    f.text(660,739,'XOR shift probability, p',61,'center')
    f.text(2095,739,'XOR shift probability, p',61,'center')
    f.text(660,1557,'Independent payloads, K',61,'center')
    f.text(2095,1557,'Readers of one payload, R',61,'center')
    for x,y,label,color in [(46,309,'Path agreement',BLUE),(1480,309,'MSE / MSE at p = 0','#171717'),
                             (46,1128,'Reconstruction MSE','#171717'),(1480,1128,'Reconstruction MSE','#171717')]:
        f.text(x,y,label,61,'center',color,angle=90)
    # Endpoint legends. Right-hand labels are raised above the last marker,
    # allowing a larger font without crossing the figure boundary.
    f.clear((1127,461,1300,515)); f.text(1128,505,'Loom',58,color=BLUE,bold=True)
    f.clear((2557,60,2730,157)); f.text(2560,104,'Far',56,color=BLUE,bold=True); f.text(2560,151,'+39%',56,color=BLUE,bold=True)
    f.clear((2557,411,2730,496)); f.text(2560,451,'Near',56,color=RED); f.text(2560,499,'+9%',56,color=RED)
    f.clear((1143,860,1400,1190))
    for label,y,color,bold in [('4 hubs',905,TEAL,False),('Static',987,PURPLE,False),('16 hubs',1045,RED,False),('Loom',1176,BLUE,True)]:
        f.text(1145,y,label,56,color=color,bold=bold)
    for box in [(2575,854,2730,900),(2575,977,2730,1030),(2575,1170,2730,1230)]:
        f.clear(box)
    for label,y,color,bold in [('Rotation',858,RED,False),('Residual',1050,TEAL,False),('Loom',1178,BLUE,True)]:
        f.text(2720,y,label,56,'right',color,bold)
    f.clear((1665,837,2150,891))
    f.line(1668,865,1744,'#222222'); f.text(1761,883,'Reader',54)
    f.line(1960,865,2036,'#222222',True); f.text(2052,883,'Source',54)
    f.clear((900,1581,2200,1647))
    # Retain the original meanings of the two bottom legend symbols.
    f.draw.ellipse((892,1602,912,1622),outline='#333333',width=5)
    f.text(936,1631,'Manuscript summary',54)
    f.draw.rectangle((1450,1593,1518,1634),fill='#e2e7ef')
    f.text(1540,1631,'Shading: ±1 SD',54)
    f.save()


def scaling():
    f = FigureType('loom_scaling.png', 'loom_scaling_readable.pdf')
    for box in [(0,0,172,857),(1810,0,2038,857),(0,1148,172,2020),
                (1810,1148,2038,1979),(175,865,1700,1020),(2040,865,3509,1020),
                (175,1998,1700,2137),(2040,1998,3509,2137)]:
        f.clear(box)
    for xs in [[256,732,1209,1566],[2121,2598,3074,3431]]:
        for x,label in zip(xs,['4k','64k','1M','8M']):
            f.text(x,916,label,73,'center')
    for x,label in zip([227,450,673,896,1120,1343,1566],['1','4','16','64','256','1024','4096']):
        f.text(x,2053,label,70,'center')
    for x,label in zip([2121,2441,2761,3082,3402],['60k','M − 1','M','M + 1','72k']):
        f.text(x,2053,label,70,'center')
    for val,y in zip(['1','2','3','4','5'],[750,599,448,298,147]):
        f.text(140,y+22,'10',68,'right'); f.text(142,y-10,val,43)
    for x,labels,ys in [(2038,['0.25','1','4','16','64'],[798,620,442,265,87]),
                        (172,['0','25','50','75','100'],[1976,1780,1584,1388,1192]),
                        (2038,['0.9','1.0','1.1','1.2'],[1934,1723,1512,1301])]:
        for label,y in zip(labels,ys):
            f.text(x,y+22,label,73,'right')
    for x,y,label in [(61,429,'Inference time (ms)'),(1879,429,'Memory (GiB)'),
                      (61,1564,'Compilation share (%)'),(1879,1564,'Cost relative to N = M')]:
        f.text(x,y,label,80,'center',angle=90)
    f.text(910,995,'Nodes N',80,'center'); f.text(2776,995,'Nodes N',80,'center')
    f.text(910,2127,'Graph reuse count Q',80,'center'); f.text(2776,2127,'Nodes near M = 65,536',80,'center')
    # Top legends occupy white areas, well above the measured traces.
    for dx in [0,1865]:
        f.clear((221+dx,20,725+dx,215))
        f.line(231+dx,58,327+dx,BLUE,marker='circle'); f.text(355+dx,79,'Loom',68)
        f.line(231+dx,124,327+dx,RED,marker='square'); f.text(355+dx,145,'SGFormer',68)
        f.draw.ellipse((245+dx,181,263+dx,199),outline=BLUE,width=5)
        f.draw.rectangle((298+dx,181,316+dx,199),outline=RED,width=5)
        f.text(355+dx,211,'Failures > 0',68)
    # Bold numerical callouts stay attached to their existing arrows.
    f.clear((900,148,1258,256))
    f.text(1258,185,'33.3× faster',68,'right',BLUE,True)
    f.text(1258,247,'at 2.10M nodes',68,'right',BLUE,True)
    f.clear((2660,130,3120,250))
    f.text(3120,178,'77.8% less memory',64,'right',BLUE,True)
    f.text(3120,240,'at 2.10M nodes',64,'right',BLUE,True)
    f.clear((1035,1172,1633,1300))
    for x,y,label,color in [(1055,1210,'64k','#328d89'),(1055,1280,'1.05M',RED),
                             (1430,1210,'2.10M',BLUE),(1430,1280,'8.39M','#8563a0')]:
        f.line(x,y-20,x+77,color,marker='circle'); f.text(x+95,y,label,64)
    f.clear((1116,1392,1540,1440))
    f.clear((1195,1445,1473,1505))
    f.text(1660,1402,'≤8.8% compilation',64,'right',BLUE,True)
    f.text(1660,1465,'at Q = 4096',64,'right',BLUE,True)
    f.clear((2083,1153,2545,1287))
    f.line(2095,1192,2191,BLUE,marker='circle'); f.text(2219,1213,'Inference',68)
    f.line(2095,1260,2191,RED,True,'square'); f.text(2219,1281,'Memory',68)
    bg=f.image.getpixel((3000,1165))
    f.clear((3020,1250,3420,1314),bg)
    f.text(3200,1304,'Latency +15.2%',64,'center',BLUE,True)
    f.clear((3020,1587,3420,1655),bg)
    f.text(3200,1641,'Memory +9.5%',64,'center',RED,True)
    f.save()


if __name__ == '__main__':
    communication()
    scaling()

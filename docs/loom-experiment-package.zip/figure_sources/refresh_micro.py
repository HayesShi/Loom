from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parents[1]
D=p/'model'
groups=['roman_empire','ogbn_arxiv']
d=pd.read_csv(D/'refresh_replay.csv')
plt.rcParams.update({'font.family':'Times New Roman','font.size':7.3,'axes.titlesize':7.3,'axes.linewidth':.5,'axes.spines.right':False,'axes.spines.top':False,'hatch.linewidth':.35,'pdf.fonttype':42})
fig,axs=plt.subplots(1,2,figsize=(3.68,1.15));fig.subplots_adjust(left=.10,right=.986,top=.79,bottom=.24,wspace=.34)
r=[];hs=[]
for j,ax in enumerate(axs):
 for k,(pol,lab,c,h) in enumerate([('low_degree','Low','#efefef','///'),('uniform','Uniform','#b4cedf',''),('high_degree','High','#e8c4a5','xx')]):
  vs=[]
  for g in groups+['ogbn_products']:
   t=d.query('graph==@g and policy==@pol');n=t.nodes.iloc[0];ns=t.changed.unique();v=t[t.changed==ns[np.argmin(abs(ns/n-.01))]]
   assert len(v)==8
   vs.append(100*(v.affected_rows.median()/n if j==0 else v.row_reaggregation_entries.median()/v.directed_entries.iloc[0]))
  bars=ax.bar(np.arange(3)+(k-1)*.22,vs,.20,color=c,edgecolor='#495058',linewidth=.4,hatch=h,label=lab)
  if j==0:hs.append(bars)
 ax.set_axisbelow(True);ax.grid(axis='y',lw=.32,color='#e0e0e0');ax.set_ylim(0,105);ax.set_yticks([0,50,100]);ax.set_xticks(range(3),['Roman','arxiv','Products'])
 ax.tick_params(length=2,pad=1,labelsize=7);ax.set_xlabel(['(a)  Affected rows','(b)  Entries scanned'][j],labelpad=1)
axs[0].set_ylabel('Graph share (%)',labelpad=1)
fig.legend(hs,['Low degree','Uniform','High degree'],loc='upper center',ncol=3,frameon=False,fontsize=7,handlelength=1.4,borderaxespad=.0,handletextpad=.3,columnspacing=.8)
fig.savefig(p/'figures/refresh_micro.pdf');plt.close(fig)

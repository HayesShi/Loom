"""CPU operator benchmark. Publish one current graph version and materialize four full reads."""
import argparse
import csv
import json
from pathlib import Path
from time import perf_counter

import graphblas as gb
import numpy as np
import scipy
from scipy import sparse

here = Path(__file__).resolve().parent


class Store:
    def __init__(self, engine, retain, x, initial_edges):
        self.engine = engine
        self.retain = retain
        self.x = x.copy()
        self.edges = set(initial_edges)
        self.prepare(True, True)

    def prepare(self, topology, features):
        if topology:
            u, v = np.asarray(sorted(self.edges), dtype=np.int32).T
            rows, cols = np.r_[u,v], np.r_[v,u]
            degree = np.bincount(rows,minlength=len(self.x)).astype(np.float32)
            weights = 1 / np.sqrt(degree[rows]*degree[cols])
            csr = sparse.csr_matrix((weights,(rows,cols)),shape=(len(degree),len(degree)))
            self.a = gb.io.from_scipy_sparse(csr) if self.engine=="GraphBLAS" else csr
        if features or not hasattr(self,"features"):
            self.features = gb.Matrix.from_dense(self.x) if self.engine=="GraphBLAS" else self.x
        if self.retain:
            self.cache = self.aggregate()

    def publish(self, edit):
        for u,v,sign in edit["edits"]:
            if sign==1:
                self.edges.add((u,v))
            else:
                self.edges.remove((u,v))
        self.x[edit["features"]] *= -1
        self.prepare(bool(edit["edits"]),bool(edit["features"]))

    def aggregate(self):
        result = self.a @ self.features
        if self.engine=="GraphBLAS":
            return result.new().to_dense(fill_value=0)
        return result

    def read(self):
        return self.cache.copy() if self.retain else self.aggregate()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("npz",type=Path)
    args=parser.parse_args()
    gb.ss.config["nthreads"]=1
    data=np.load(args.npz)
    x=np.ascontiguousarray(data["x"],dtype=np.float32)
    edges=[(u,v) for u,v in data["edge_index"].T.tolist() if u<v]
    trace=json.loads((here/"dynamic/trace.json").read_text())
    rows=[]
    rng=np.random.default_rng(582)
    modes=[(e,r) for e in ("SciPy","GraphBLAS") for r in (False,True)]
    # Untimed warm-up on all code paths before construction and stream timing.
    for e,r in modes:
        test=Store(e,r,x[:8],[(0,1),(1,2),(2,3)])
        test.read()
    stores={}
    for j in rng.permutation(len(modes)):
        e,r=modes[j]
        t=perf_counter()
        stores[e,r]=Store(e,r,x,edges)
        stores[e,r].setup=perf_counter()-t
    for i,edit in enumerate(trace,1):
        oracle=None
        for j in rng.permutation(len(modes)):
            e,r=modes[j]
            s=stores[e,r]
            t=perf_counter()
            s.publish(edit)
            publish_s=perf_counter()-t
            for q in range(1,5):
                t=perf_counter()
                out=s.read()
                read_s=perf_counter()-t
                if oracle is None:
                    oracle=out.copy()
                error=np.abs(out-oracle).max()
                assert np.allclose(out,oracle,rtol=2e-5,atol=2e-5)
                rows.append(dict(version=i,operation=edit["kind"],read=q,engine=e,
                                 policy="retain" if r else "recompute",initial_s=s.setup,
                                 publish_s=publish_s,read_s=read_s,max_abs=float(error)))
    with (here/"versioned_reads.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    print("Versions",len(trace),"dense MiB",x.nbytes/2**20,
          "SciPy",scipy.__version__,"python-graphblas",gb.__version__,
          "SuiteSparse",gb.ss.about["library_version"])


if __name__=="__main__":
    main()


"""Render annotated Loom panels from the supplied data, then assemble the atlas."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from matplotlib.ticker import NullLocator
import pymupdf

ROOT = Path(__file__).resolve().parent
DATA = pd.read_csv(ROOT / 'values.csv')
INK = '#262b30'
RULE = '#a1a8ad'
ACCENT = '#a54e1c'
WASH = '#f8eee4'
METHODS = ['Identity','Gray','Rabbit','GOrder','METIS-128','Fiedler','Loom']
STYLES = {
    'Identity': ('#535961','o','-'), 'Gray': ('#536e88','s','--'),
    'Rabbit': ('#5d857c','^','-.'), 'GOrder': ('#75688a','v',':'),
    'METIS-128': ('#8a775c','P','--'), 'Fiedler': ('#457485','X',':'),
    'Loom': (ACCENT,'D','-')}
STYLES['METIS-1024'] = STYLES['METIS-128']
plt.rcParams.update({'font.family':'Times New Roman','mathtext.fontset':'stix','font.size':7,
    'axes.labelsize':7.4,'axes.titlesize':8,'axes.edgecolor':'#42484b','axes.linewidth':.55,
    'axes.spines.right':False,'axes.spines.top':False,'axes.labelpad':2,'xtick.labelsize':6.6,
    'ytick.labelsize':6.6,'xtick.major.size':2,'ytick.major.size':2,'xtick.major.pad':2,
    'ytick.major.pad':2,'hatch.linewidth':.33,'pdf.fonttype':42,'svg.fonttype':'none'})
def values(n,p):
    return DATA[(DATA.figure==n)&(DATA.panel==p)]
def start(n,title,height):
    f=plt.figure(figsize=(7.12,height))
    f.text(.014,.974,f'Fig. S{n}.  {title}',va='top',weight='bold',size=9.4)
    return f
def panel(f,box,title):
    a=f.add_axes(box);a.set_axisbelow(True);a.grid(axis='y',color='#dee1e2',lw=.4)
    a.set_title(title,loc='left',pad=3,weight='bold')
    return a
def caption(f,text,y=.019):
    f.text(.014,y,text,fontsize=6.8,va='bottom',color=INK)
def legend(f,methods,y):
    handles=[]
    for m in methods:
        c,mk,ls=STYLES[m]
        handles.append(Line2D([],[],color=c,ls=ls,marker=mk,ms=3,lw=1.3 if m=='Loom' else .85,
                              mfc=c if m=='Loom' else 'white',mew=.65))
    f.legend(handles,methods,loc='upper center',bbox_to_anchor=(.50,y),ncol=len(methods),frameon=False,
             borderaxespad=0,handlelength=2.15,handletextpad=.35,columnspacing=1.05)
def line(a,x,y,m,mark=None):
    c,mk,ls=STYLES[m]
    a.plot(x,y,ls=ls,color=c,marker=mk,ms=3.1 if m=='Loom' else 2.7,
           mfc=c if m=='Loom' else 'white',mew=.62,lw=1.35 if m=='Loom' else .82,
           zorder=5 if m=='Loom' else 3,markevery=mark)
def table(f,box,methods,groups,headers,body,widths,bold_cells=(),first_header=None):
    """Booktabs-style table with spanner headers and one layout column."""
    ax=f.add_axes(box);ax.set_axis_off()
    edges=np.r_[0,np.cumsum(widths)];edges=edges/edges[-1]
    centers=(edges[1:]+edges[:-1])/2
    n=len(methods);ax.set_xlim(0,1);ax.set_ylim(n+2.12,-.03)
    ax.hlines([0,1.98,n+1.98],0,1,color=INK,linewidths=[.76,.45,.76])
    ax.vlines(edges,0,n+1.98,lw=.32,color=RULE)
    c=1
    for name,count in groups:
        ax.text((edges[c]+edges[c+count])/2,.50,name,ha='center',va='center',weight='bold',fontsize=7.2)
        ax.hlines(.97,edges[c]+.005,edges[c+count]-.005,color=RULE,lw=.42);c+=count
    ax.text(.008,1.49,first_header or ('Layout' if methods[0]!='Build' else 'Stage'),va='center',weight='bold',size=7.2)
    for i,h in enumerate(headers,1):
        ax.text(centers[i],1.49,h,ha='center',va='center',size=7)
    for r,m in enumerate(methods):
        ax.text(.008,2.48+r,m,va='center',size=7.1,weight='bold' if m=='Loom' else 'normal',color=ACCENT if m=='Loom' else INK)
        for c,s in enumerate(body[r],1):
            ax.text(centers[c],2.48+r,s,va='center',ha='center',size=7.15,weight='bold' if (r,c-1) in bold_cells else 'normal')
    return ax
def save(f,n):
    f.savefig(ROOT.parent/'figures'/f'f{n}.pdf')
    plt.close(f)
def payback():
    f=start(3,'Compilation cost and query payback',1.87)
    legend(f,METHODS,.887)
    comp=values(3,'compile').pivot(index='method',columns='dataset',values='value')
    pay=values(3,'break-even').pivot(index='method',columns='dataset',values='value')
    body=[]
    for m in METHODS:
        v=[f'{comp.loc[m,g]:.3f}' for g in ('Plate','arxiv')]
        for g in ('Plate','arxiv'):
            q=pay.loc[m,g];v.append('—' if m=='Identity' else (f'{q:.0f}' if np.isfinite(q) else '∞'))
        body.append(v)
    table(f,[.013,.205,.387,.538],METHODS,[('Compile (s)',2),('Payback Q',2)],['Plate','arxiv']*2,body,[1.48,1,1,1,1])
    for j,g in enumerate(['Plate','arxiv']):
        a=panel(f,[.462+j*.279,.31,.238,.378],f'({chr(97+j)})  {g} · cumulative time / Identity')
        t=values(3,'total').query('dataset==@g').pivot(index='method',columns='x',values='value')
        qs=np.unique(np.r_[np.geomspace(1,5000,165),t.columns])
        for m in METHODS:
            line(a,qs,np.interp(qs,t.columns,t.loc[m])/np.interp(qs,t.columns,t.loc['Identity']),m,np.searchsorted(qs,t.columns).tolist())
        a.set_xscale('log');a.set_yscale('log');a.set_ylim(.30,12);a.set_yticks([.5,1,2,5,10],['.5','1','2','5','10']);a.yaxis.set_minor_locator(NullLocator())
        a.set_xticks([1,10,100,1000,5000],['1','10','100','1k','5k']);a.set_xlabel('Requests')
    st=values(3,'Archived stream').set_index('method').value
    caption(f,f"Measured Plate stream (1,000 requests): full compile {st['Full compile']:.1f} s, reference reuse {st['Reference reuse']:.1f} s.",.082)
    caption(f,'Loom on arxiv uses archived cost components. Payback uses scenario baselines; ∞ = no lasting payback.')
    save(f,3)
def gpu():
    f=start(4,'GPU execution across layouts and backends on arxiv',1.58)
    ms=['Identity','Rabbit','GOrder','METIS-1024','Loom']
    bs=['Indexed','Grouped','Fused','DGL','Opt. sparse']
    t=values(4,'Device time (ms)').pivot(index='method',columns='dataset',values='value').loc[ms,bs]
    ratio=t.div(t.iloc[0]);body=[]
    for m in ms:
        row=[f'{v:.0f}' for v in t.loc[m]]
        for p,places in [('Cache hits (%)',1),('DRAM (GiB)',2)]:
            row.extend(f'{v:.{places}f}' for v in values(4,p).query('method==@m').sort_values('x').value)
        row.extend(f'{v:.2f}' for v in ratio.loc[m]);body.append(row)
    bk=['Idx','Grp','Fused','DGL','Opt']
    table(f,[.013,.171,.976,.681],ms,[('Device time (ms)',5),('Cache hits (%)',2),('DRAM (GiB)',2),('Time / Identity (×)',5)],
          bk+['L1','L2','Read','Write']+bk,body,[1.95]+[1]*14,{(4,c) for c in range(3)})
    caption(f,'Bold times are measured GPU-event medians. All other inputs are simulated. Ratios use the Identity time for the same backend.',.081)
    caption(f,'Idx = indexed; Grp = grouped; Opt = optimized sparse kernel.')
    save(f,4)
def scaling():
    f=start(5,'Scale, memory use and cold-start capacity',1.87)
    ms=['Identity','Rabbit','METIS-1024','Gray','Fiedler','Loom'];legend(f,ms,.887)
    for j,(p,title) in enumerate([('Node sweep','Node sweep (ms)'),('Edge sweep','Edge sweep (ms)'),('Peak memory','Loom peak (GiB)')]):
        a=panel(f,[.061+j*.246,.305,.197,.392],f'({chr(97+j)})  {title}')
        t=values(5,p)
        if j<2:
            for m in ms:
                s=t[t.method==m].sort_values('x');line(a,s.x if j==0 else s.x/262144,s.value,m)
        else:
            for dev,m in [('CPU','Identity'),('GPU','Loom')]:
                s=t[t.dataset==dev].sort_values('x');line(a,s.x,s.value,m)
                end=s.iloc[-1]
                dy=3 if dev=='GPU' else -12
                a.annotate(f'{dev} {end.value:.2f}',(end.x,end.value),xytext=(-2,dy),
                           textcoords='offset points',ha='right',va='bottom' if dev=='GPU' else 'top',
                           fontsize=6.5,color=STYLES[m][0],bbox=dict(facecolor='white',edgecolor='none',pad=.1))
            a.set_ylim(.015,18)
        a.set_xscale('log');a.set_yscale('log');a.yaxis.set_minor_locator(NullLocator())
        if j!=1:a.set_xticks([4096,65536,2097152],['4k','65k','2.1M'])
        else:a.set_xticks([2,8,32,128],['2','8','32','128'])
        a.set_xlabel(['Nodes · 8 entries/node','Entries/node · 262k nodes','Nodes'][j])
    z=values(5,'Cold start').pivot(index='dataset',columns='x',values='value').loc[['Compile','Load','Forward']]
    body=[['—' if v==0 else ('OK' if v==1 else 'T/O') for v in r] for r in z.to_numpy()]
    table(f,[.762,.30,.226,.405],['Build','Load','Infer'],[('Cold start (M nodes)',3)],['2.10','4.19','8.39'],body,[1.15,1,1,1])
    caption(f,'Measured: Loom node sweep, GPU allocation and cold-start outcomes. Other series are simulated.',.083)
    caption(f,'T/O = timeout; — = no stage result. The manuscript reports a separate 8.39M-node run with a compiled layout.')
    save(f,5)
def updates():
    f=start(6,'Feature updates on ogbn-products',2.56)
    scenarios = pd.read_csv(ROOT/'products_scenarios.csv')
    medians = scenarios.groupby(['pool','profile','update_pct','method']).maintenance_ms.median().unstack('method')
    gains = medians.drop(columns='Loom').min(axis=1) / medians['Loom']
    ms=['Full re-aggregation','Affected rows','Incremental','Loom']
    fills=['#d1d4d6','#a3bed1','#9bc3b6','#dca587'];edges=['#6c7376','#58758a','#59796e',ACCENT];hatches=['//','','..','\\\\']
    handles=[Patch(facecolor=c,edgecolor=e,hatch=h,linewidth=.55) for c,e,h in zip(fills,edges,hatches)]
    f.legend(handles,ms,ncol=4,loc='upper center',bbox_to_anchor=(.54,.917),borderaxespad=0,frameon=False,handlelength=1.75,columnspacing=1.4)
    for j,(g,left,width) in enumerate([('Low degree',.075,.25),('Uniform',.349,.35),('High degree',.726,.26)]):
        for i,p in enumerate(['Maintenance (ms)','Prediction P95 (ms)']):
            a=panel(f,[left,[.55,.155][i],width,[.24,.25][i]],f'({chr(97+j)})  {g}' if i==0 else '')
            t=values(6,p).query('dataset==@g').pivot(index='method',columns='x',values='value').dropna(axis=1)
            if i == 1:
                t = t.subtract(t.loc['Full re-aggregation'], axis='columns')
            x=np.arange(len(t.columns));bottom=.5 if i==0 else 0
            for k,m in enumerate(ms):
                bars=a.bar(x+(k-1.5)*.232,t.loc[m]-bottom,width=.190,bottom=bottom,color=fills[k],edgecolor=edges[k],linewidth=.48,hatch=hatches[k],zorder=3)
                for bar,value in zip(bars,t.loc[m]):
                    a.annotate(f'{value:.1f}',(bar.get_x()+bar.get_width()/2,value),
                               xytext=(0,1.5),textcoords='offset points',rotation=90,
                               ha='center',va='bottom',fontsize=5.65,color=ACCENT if m=='Loom' else '#34383a',
                               weight='bold' if m=='Loom' else 'normal',zorder=5)
            a.set_xlim(-.50,len(x)-.50)
            if i==0:
                a.set_yscale('log');a.set_yticks([1,10,100],['1','10','100']);a.set_ylim(.5,720);a.yaxis.set_minor_locator(NullLocator());a.set_xticks([])
                central=gains.loc[(g,'Central')]
                for idx,pct in enumerate(t.columns):
                    a.text(idx,-.09,f'{central.loc[pct]:.2f}×',transform=a.get_xaxis_transform(),
                           ha='center',va='top',fontsize=6.4,color=ACCENT,weight='bold',clip_on=False)

            else:
                a.set_ylim(0,55);a.set_yticks([0,15,30,45]);a.set_xticks([])
            if j==0:a.set_ylabel(['Update time\n(ms)','Extra P95\nbudget (ms)'][i])
            else:a.tick_params(labelleft=False)
        a.set_xticks(x,[f'{pct:g}%' for pct in t.columns])
    caption(f,'Ochre ratios: fastest control / Loom maintenance (central scenario). Extra P95 is above 55 ms. Uniform 20% and 50% are extrapolated.')
    save(f,6)

"""Measured Plate service and arxiv execution panels. Regenerate from archive_inputs."""
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parents[1]
inputs = root / "archive_inputs"
data = pd.read_csv(inputs / "plate_instances.csv")
keys = ["request", "simulation_id", "split"]
full, reuse = [data[data.method == method].set_index(keys).sort_index() for method in
               ["full_compile", "reference_reuse"]]
assert full.index.equals(reuse.index) and full.index.is_unique and len(full) == 1000
save_ms = 1000*(full.request_s-reuse.request_s)
windows = [(1,100), (101,300), (301,1000)]
blue, orange, green = "#355F83", "#A14F22", "#3E7B71"
plt.rcParams.update({"font.family":"Times New Roman", "font.size":7.8, "axes.linewidth":.55,
    "axes.spines.top":False,"axes.spines.right":False,"xtick.labelsize":7.2,"ytick.labelsize":7.2,
    "xtick.major.size":2.5,"ytick.major.size":2.5,"axes.labelpad":1.5,"pdf.fonttype":42})
fig, axes = plt.subplots(1,4,figsize=(7.10,1.70))
fig.subplots_adjust(left=.057, right=.987, top=.75, bottom=.245, wspace=.50)
for ax,title in zip(axes,["(a)  Stream cost","(b)  Savings quantiles","(c)  Stage savings","(d)  Individual requests"]):
    ax.set_title(title,loc="left",fontsize=8.5,fontweight="bold",pad=10)
    ax.set_axisbelow(True); ax.grid(axis="y",lw=.35,color="#dde0e2")
ax=axes[0]
for b,col,ls,yoff in [(full,blue,"-",3),(reuse,orange,"--",-8)]:
    ax.plot(b.index.get_level_values("request"), b.cumulative_s,color=col,ls=ls,lw=1.25)
    ax.annotate(f"{b.cumulative_s.iloc[-1]:.1f}",(1000,b.cumulative_s.iloc[-1]),
                xytext=(-1,yoff),textcoords="offset points",ha="right",color=col,fontsize=7.4)
ax.set(xlim=(0,1030),ylim=(0,204),xlabel="Request index",ylabel="Cumulative time (s)")
ax.text(.02,.96,f"Per-case   {len(full)/full.cumulative_s.iloc[-1]:.2f} req/s",va="top",color=blue,transform=ax.transAxes)
ax.text(.02,.80,f"Reuse       {len(reuse)/reuse.cumulative_s.iloc[-1]:.2f} req/s",va="top",color=orange,transform=ax.transAxes)
pct=np.arange(5,96)
phases=["layout_s","forward_s","request_s"]
lines=[]
for (lo,hi),col,ls,marker in zip(windows,[blue,green,orange],["-","--","-."],["o","s","D"]):
    ds=save_ms.loc[lo:hi]
    y=np.percentile(ds,pct)
    axes[1].plot(pct,y,color=col,ls=ls,marker=marker,markevery=[45],ms=3,lw=1.2)
    lines.append([lo,hi,len(ds),int((ds>0).sum()),*ds.quantile([.1,.5,.9]).tolist()])
axes[1].set(xlabel="Percentile of paired requests",ylabel="Time saved (ms)",xticks=[5,25,50,75,95],xlim=(4,96))
axes[1].axhline(0,lw=.5,color=".35")
x=np.arange(3)
for j,(phase,col,hatch) in enumerate(zip(phases,[blue,green,orange],["//","..",""])):
    means=[(1000*(full[phase]-reuse[phase]).loc[a:b]).mean() for a,b in windows]
    bars=axes[2].bar(x+(j-1)*.25,means,.20,color=col,alpha=.87,hatch=hatch,edgecolor="white",linewidth=.25)
    for bar,v in zip(bars,means):
        axes[2].annotate(f"{v:.1f}",(bar.get_x()+bar.get_width()/2,v),ha="center",
                         va="top" if v<0 else "bottom",fontsize=6.4)
axes[2].set(xticks=x,xticklabels=["1–100","101–300","301–1k"],xlabel="Request window",ylabel="Mean saved (ms)",ylim=(-7,60))
axes[2].axhline(0,color=".35",lw=.45)
fig.text(.301,.953,"1–100",color=blue,fontsize=6.5);fig.text(.354,.953,"101–300",color=green,fontsize=6.5);fig.text(.424,.953,"301–1k",color=orange,fontsize=6.5)
for xlab,lab,col in [(.563,"Layout",blue),(.621,"Forward",green),(.695,"Total",orange)]:
    fig.text(xlab,.953,lab,color=col,fontsize=6.5)
ax=axes[3]
for (lo,hi),col in zip(windows,[blue,green,orange]):
    ds=save_ms.loc[lo:hi]
    ax.scatter(ds.index.get_level_values("request"),ds,s=2.3,c=col,alpha=.53,linewidths=0)
ax.axhline(0,lw=.55,color=".35")
ax.set_yscale("symlog",linthresh=20)
ax.set_yticks([-10,0,20,60,160,320],["−10","0","20","60","160","320"])
ax.set(xlim=(-20,1020),xticks=[1,500,1000],xlabel="Request index",ylabel="Time saved (ms)")
fig.savefig(root/"figures/plate_paired.pdf")
plt.close(fig)
q=pd.DataFrame(lines,columns=["start","end","requests","reuse_wins","p10_ms","p50_ms","p90_ms"])
q.to_csv(root/"model/plate_paired_summary.csv",index=False)
def row(v): return " & ".join(v)+r"\\"
def best(x):return r"\textbf{"+x+"}"
def export(name,body): (root/"sections"/f"{name}.tex").write_text("\n".join(body),encoding="utf8")
rows=[r"\tcap{Paired latency by Plate stream window.}",r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}l|rr|rrr@{}}\hline",
      r"&\multicolumn{2}{c|}{Requests}&\multicolumn{3}{c}{Compile minus reuse (ms)}\\",
      r"Window & Paired & Faster$^*$ & P10 & P50 & P90\\\hline"]
for v in lines+[[1,1000,len(save_ms),(save_ms>0).sum(),*save_ms.quantile([.1,.5,.9])]]:
    if v[1]-v[0]==999:rows.append(r"\hline")
    rows.append(row([f"{v[0]}--{v[1]:,}",f"{v[2]:,}",str(v[3]),*[f"{f:.2f}" for f in v[4:]]]))
export("plate_pairs",rows+[r"\hline\end{tabular*}",r"\tabnote{$^*$Cases with lower latency under reuse. Quantiles summarize paired differences. Startup is included only in Fig.~1(a).}"])

g=pd.read_csv(inputs/"gpu_trials.csv").set_index(["scope","variant"])
trace=pd.read_csv(inputs/"gpu_trace_summary.csv").query("phase=='butterfly_ARCO'").set_index("variant")
eq=pd.read_csv(inputs/"gpu_equivalence.csv").set_index("variant")
rows=[r"\tcap{arxiv GPU execution. Fixed layout, weights and precision; latency per full call in milliseconds.}",
r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}l|rrr|rrr|rr|r@{}}\hline",
r"&\multicolumn{3}{c|}{Fresh neighbors} &\multicolumn{3}{c|}{Cached neighbors}&\multicolumn{2}{c|}{Fresh ARCO trace}&Cached logits\\",
r"Execution & GPU P50 & Wall P95 & MiB & GPU P50 & Wall P95 & MiB & Calls & Kernel ms & Relative $L_2$\\\hline"]
for method,label in [("indexed","Indexed"),("grouped","Grouped"),("fused_grouped","Fused")]:
    cell=[label]
    for scope in ["fresh_neighbors","cached_neighbors"]:
        for key in ["gpu_ms_median","wall_ms_p95","peak_allocated_MiB_median"]:
            val=g.loc[(scope,method),key]
            v=f"{val:,.2f}"
            cell.append(best(v) if val==g.loc[scope,key].min() else v)
    cell.extend([f"{trace.loc[method,'kernel_calls']:,}",f"{trace.loc[method,'total_kernel_ms']:.2f}",
                 r"$1.68\times10^{-7}$" if method!="fused_grouped" else "Reference"])
    rows.append(row(cell))
export("gpu_panel",rows+[r"\hline\end{tabular*}",r"\tabnote{Bold marks the column minimum. Latency and memory use 15 trials. Kernel counts come from a separate profiler run. Test accuracy is 65.368\% for all three implementations.}"])


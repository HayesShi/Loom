"""Conditional scenarios. All latency coefficients below are assumptions, in milliseconds."""
from pathlib import Path
import math
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SECTIONS = ROOT.parent / "sections"
atlas = pd.read_csv(ROOT / "atlas_input.csv")
replay = pd.read_csv(ROOT / "refresh_replay.csv").query("graph == 'ogbn_products'").copy()
replay["fraction"] = replay.changed / replay.nodes
pools = {"Low degree": "low_degree", "Uniform": "uniform", "High degree": "high_degree"}
methods = ["Full re-aggregation", "Affected rows", "Incremental", "Loom"]
# launch cost, incident-entry work, affected-row work, saturation penalty
profiles = {"Favorable": (0.70, 105., 15., 5.), "Central": (1.05, 155., 23., 18.),
            "Contended": (2.60, 260., 38., 48.)}

def shares(batch, frac):
    """Interpolate within one seed. Beyond 10%, model saturation only for uniform sampling."""
    batch = batch.sort_values("fraction")
    x = batch.fraction.to_numpy()
    series = (batch.incident_entries / batch.directed_entries,
              batch.affected_rows / batch.nodes, batch.row_reaggregation_entries / batch.directed_entries)
    if frac <= x[-1]:
        return [np.interp(frac, x, y) for y in series]
    incident, rows, scan = [s.iloc[-1] for s in series]
    return [min(1., incident*frac/x[-1]), 1-(1-rows)**(frac/x[-1]), 1-(1-scan)**(frac/x[-1])]

def costs(i, r, s, profile):
    launch, inc, row, penalty = profiles[profile]
    maintain = [85., 2.3+110*s, 1.9+270*i+60*r,
                launch+inc*i+row*r+penalty*r*r]
    # Post-update P95 budget: 55 ms common forward path plus assumed tail cost
    # of strategy-specific fragmented access. This is not an empirical quantile.
    predict = [55., 55.+12.*r, 55.+21.*r+12.*r*r, 55.+5.*r+4.*r*r]
    return maintain, predict

out = []
for pool, policy in pools.items():
    for frac in ([.1, 1, 2, 5, 10, 20, 50] if pool == "Uniform" else [.1, 1, 2, 5, 10]):
        for seed, sample in replay[replay.policy == policy].groupby("seed"):
            i, r, s = shares(sample, frac/100)
            for profile in profiles:
                update, predict = costs(i, r, s, profile)
                for method, latency, tail in zip(methods, update, predict):
                    out.append((profile, pool, frac, seed, method, i, r, s, latency, tail,
                                "extrapolated" if frac > 10 else "replay/interpolation", "simulated"))
grid = pd.DataFrame(out, columns=["profile","pool","update_pct","seed","method","incident","rows","scan",
                                  "maintenance_ms","prediction_p95_budget_ms","work_source","status"])
grid.to_csv(ROOT/"products_scenarios.csv", index=False)
central = grid[grid.profile=="Central"].groupby(["pool","method","update_pct"]).median(numeric_only=True)
for idx, rec in atlas[(atlas.figure==6)&(atlas.status=="simulated")].iterrows():
    col = "maintenance_ms" if rec.panel=="Maintenance (ms)" else "prediction_p95_budget_ms"
    atlas.at[idx,"value"] = central.loc[(rec.dataset,rec.method,rec.x), col]
    atlas.at[idx,"source"] = "products_scenarios.csv / central median"
atlas.loc[(atlas.figure==3)&(atlas.panel=="total")&(atlas.status=="measured"),"status"]="derived"
atlas.to_csv(ROOT/"values.csv",index=False)
def y(s):
    return str(s)
def table(cap, cols, heads, rows, note):
    return "\n".join([r"\tcap{"+cap+"}",r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}|"+cols+"|}"+r"\hline",
                      heads, r"\hline", *rows,r"\hline\end{tabular*}",r"\tabnote{"+note+"}"])
def line(cells):
    return " & ".join(cells)+r" \\"
rows=[]
for pool in pools:
    for pct in (.1,1,5,10):
        data=grid[(grid.pool==pool)&(grid.update_pct==pct)]
        med=data.groupby(["profile","method"]).maintenance_ms.median().unstack()
        ref=med.loc["Central",methods[:3]]
        base_name={"Full re-aggregation":"Full","Affected rows":"Rows","Incremental":"Delta"}[ref.idxmin()]
        gains=[ref.min()/med.loc[p,"Loom"] for p in profiles]
        rows.append(line([pool if pct==.1 else "",f"{pct:g}",y(base_name),
                          y(f"{ref.min():.1f}"),y(f"{med.loc['Central','Loom']:.1f}"),
                          *[y(f"{v:.2f}") for v in gains]]))
    rows.append(r"\hline")
(SECTIONS/"update_targets.tex").write_text(table("Products maintenance against the fastest control at each operating point.",
    "lr|lr|r|rrr",line(["Pool",r"Update (\%)","Winner$^*$","Best (ms)","Loom (ms)","Favorable $\\times$","Central $\\times$","Contended $\\times$"]),
    rows[:-1],r"$^*$Fastest of full, affected-row and delta maintenance under the cost model. Compare medians over the same eight replay seeds. Loom time is central; speedup is best-control time divided by Loom time. Coefficients are specified in Appendix S."),encoding="utf8")

rows=[]; gpu=[]
for name, acceleration, overhead in [("Dispatch-bound",1.10,65.),("Moderate fusion",1.55,12.),("Bandwidth target",2.4,6.),("Stretch target",3.2,4.)]:
    # Baseline starts with a cached compiled layout. Charge Loom the entire extra build
    # cost; identical request loading is outside both boundaries.
    warm = (579.08-541.268)+541.268/acceleration+overhead
    qstar=math.floor(9248.863/(579.08-warm))+1 if warm<579.08 else None
    qs=(10,50,100,1000)
    gains=[q*579.08/(9248.863+q*warm) for q in qs]
    gpu.append([name,acceleration,overhead,warm,qstar,*gains,"simulated"])
    rows.append(line([name,y(f"{acceleration:.2f}"),y(f"{overhead:.0f}"),y(f"{warm:.1f}"),y(qstar or r"$\infty$"),*[y(f"{v:.2f}") for v in gains]]))
pd.DataFrame(gpu,columns=["profile","phase_speed_factor","extra_ms","warm_ms","first_win_Q","Q10","Q50","Q100","Q1000","status"]).to_csv(ROOT/"gpu_targets.csv",index=False)
(SECTIONS/"gpu_targets.tex").write_text(table("arxiv: additional fusion versus the fastest measured cached implementation (579.08 ms).",
 "l|rr|rr|rrrr",line(["Scenario",r"Phase $\times$","Extra ms","Warm ms",r"$Q^*$",r"$Q=10$",r"$50$",r"$100$",r"$1{,}000$"]),rows,
 r"Last four columns give lifetime speedup. For phase speed factor $k$ and extra dispatch cost $h$, $T=579.08-541.268+541.268/k+h$ ms. Loom pays an extra 9.249 s layout build; the cached fused reference starts ready. $Q^*$ is the first strictly faster request count. Phase and full-call medians come from separate trials, so this decomposition is approximate."),encoding="utf8")


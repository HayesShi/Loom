"""Render paired CPU replay, GPU reuse curves and explicit joint design budgets."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import NullLocator
import redesign as atlas

root = Path(__file__).resolve().parents[1]
model = root / "model"
archive = root / "archive_inputs"
figures = root / "figures"
sections = root / "sections"
blue, orange, teal, grey, plum = "#315D83", "#A44C30", "#38786A", "#636971", "#756080"
def table(file, title, spec, header, rows, note):
    lines=[r"\tcap{"+title+"}", r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}"+spec+r"}\hline",
           header+r"\\\hline"]
    lines.extend(" & ".join(map(str,row))+r"\\" for row in rows)
    lines.extend([r"\hline\end{tabular*}",r"\tabnote{"+note+"}"])
    (sections/(file+".tex")).write_text("\n".join(lines)+"\n",encoding="utf8")

base=pd.read_csv(model/"dynamic/trials.csv")
sweep=pd.read_csv(model/"dynamic/sweep_trials.csv")
raw=pd.concat([base,sweep],ignore_index=True)
assert len(raw)==160 and raw.label_mismatches.max()==0 and raw.max_logit_delta.max()==0
cases=[(k.title(),base[base.kind==k]) for k in ("feature","insert","delete","mixed")]
cases += [(f"{pool}, {n}",sweep[(sweep.kind==pool)&(sweep.edge_batch==n)])
          for n in (8,128) for pool in ("Low","Uniform","High")]
rows=[]
for label,g in cases:
    a,b=[g[g["mode"]==m].set_index("batch").sort_index() for m in ["direct","d2ts"]]
    assert a.index.equals(b.index) and len(a)==8
    vals=[label,f"{a.rows.median():g}",f"{b.rows.median():g}"]
    for col in ("maintenance_ms","e2e_ms"):
        for series in [a[col],b[col]]:
            vals.append(f"{series.median():.2f} / {series.quantile(.95):.2f}")
    vals.extend([f"{b.maintenance_ms.median()/a.maintenance_ms.median():.2f}",
                 f"{b.e2e_ms.median()/a.e2e_ms.median():.2f}"])
    rows.append(vals)
table("dynamic_results","Receipt-to-logits measurements on Roman Empire. Each cell reports P50 / P95 in ms.",
      "|l|rr|rr|rr|rr|",r"&\multicolumn{2}{c|}{Rows refreshed}&\multicolumn{2}{c|}{Maintenance (ms)}&\multicolumn{2}{c|}{End to end (ms)}&\multicolumn{2}{c|}{P50 ratio}\\\cline{2-9} Batch or pool & Direct & D2TS & Direct & D2TS & Direct & D2TS & Maint. & Total",
      rows,r"Ratios divide D2TS by direct medians. Eight batches per cell; P95 uses linear interpolation across whole requests. Row counts are medians. The direct adapter can refresh extra rows when edits cancel a degree change.")
# The two halves of Fig. 4 have the same 264.96 x 82.8 pt canvas.
# Positions are in points, matching the original refresh_micro vector.
def update_half(filename, sweep_panels=False):
    width, height = 264.96, 82.80
    fig = plt.figure(figsize=(width/72,height/72))
    axes = [fig.add_axes([x/width,20.5/height,99/width,45/height]) for x in (27,161)]
    modes = [("direct","#e4bb9d","#985023","//"),("d2ts","#a4bccb","#4e6e83","")]
    fig.legend([Patch(facecolor=fill,edgecolor=edge,hatch=hatch,lw=.55)
                for _,fill,edge,hatch in modes],["Direct adapter","D2TS"],
               loc="upper center",bbox_to_anchor=(.52,1.025),frameon=False,ncol=2,
               fontsize=7,handlelength=1.7,handletextpad=.35,columnspacing=1.5,borderaxespad=0)
    for i,ax in enumerate(axes):
        ax.grid(axis="y",lw=.35,color="#dde0e2"); ax.set_axisbelow(True)
        categories = ["Low","Uniform","High"] if sweep_panels else ["feature","insert","delete","mixed"]
        metric = "maintenance_ms" if sweep_panels or i==0 else "e2e_ms"
        for j,(mode,fill,edge,hatch) in enumerate(modes):
            positions = np.arange(len(categories))+(j-.5)*.36
            groups = [(sweep[(sweep.kind==k)&(sweep.edge_batch==(8,128)[i])]
                       if sweep_panels else base[base.kind==k]) for k in categories]
            samples = [g.loc[g["mode"]==mode,metric] for g in groups]
            med = np.array([v.median() for v in samples])
            if metric=="e2e_ms":
                for x,v,m in zip(positions,samples,med):
                    ax.vlines(x,v.min(),v.max(),color=edge,lw=.75)
                    ax.plot(x,m,marker=("o","s")[j],color=edge,ms=2.8)
            else:
                bars=ax.bar(positions,med,width=.31,color=fill,edgecolor=edge,hatch=hatch,lw=.55)
                for bar,m in zip(bars,med):
                    ax.annotate(f"{m:.1f}",(bar.get_x()+bar.get_width()/2,m),
                                xytext=((-1.3,1.2) if j==0 else (1.3,1.2)),textcoords="offset points",
                                ha="center",fontsize=5.8,color=edge)
        ax.set_xticks(range(len(categories)),["Low","Unif.","High"] if sweep_panels else ["Feat.","Ins.","Del.","Mix"])
        ax.set_ylabel("P50 (ms)" if metric=="maintenance_ms" else "Latency (ms)",fontsize=7)
        titles = ["(a)  Eight edge edits","(b)  128 edge edits"] if sweep_panels else ["(c)  Maintenance","(d)  Receipt to logits"]
        ax.set_xlabel(titles[i],labelpad=1,fontsize=7.2)
        if sweep_panels:
            ax.set(ylim=(0,(5,58)[i]),yticks=([0,2,4],[0,20,40])[i])
        elif i==0: ax.set(ylim=(0,5.6),yticks=[0,2,4])
        else: ax.set(ylim=(260,710),yticks=[300,500,700])
    fig.savefig(figures/filename);plt.close(fig)

update_half("dynamic_cpu.pdf")
update_half("dynamic_degree.pdf",sweep_panels=True)

def load_case(name):
    return json.loads((archive/f"synthetic_2097152_{name}.json").read_text())
l,s=map(load_case,["loom","sgformer"])
def components(d):
    return np.array([d["compile_ms"]/1000,d["first_full_inference_ms"]/1000,
                     d["end_to_end"]["median_ms"]/1000,d["end_to_end"]["peak_allocated_MiB"]])
lc,sc=map(components,[l,s])
cases_gpu={"SGFormer":sc,"Loom eager":lc}
for k in [1.5,2,5]:
    cases_gpu[f"Forward / {k:g}"]=lc/[1,k,k,1]
cases_gpu["Joint target"]=np.array([3,lc[1]/5,lc[2]/5,4096])
def cost(c,q):
    return c[0]+c[1]+(q-1)*c[2]
def crossing(c):
    if cost(c,1)<cost(sc,1): return 1
    if c[2]>=sc[2]: return None
    return 2+int(np.floor((cost(c,1)-cost(sc,1))/(sc[2]-c[2])))
qs=[1,10,50,100,227,1000,2488]
rows=[]; ledger=[]
for name,c in cases_gpu.items():
    qstar=crossing(c) if name!="SGFormer" else None
    if qstar:
        assert cost(c,qstar)<cost(sc,qstar) and (qstar==1 or cost(c,qstar-1)>=cost(sc,qstar-1))
    rows.append([name,*[f"{v:.3f}" for v in c[:3]],f"{c[3]:,.0f}",
                 "---" if name=="SGFormer" else (str(qstar) if qstar else r"$\infty$"),
                 *[f"{cost(sc,q)/cost(c,q):.2f}" for q in qs]])
    for q in qs:
        ledger.append([name,"measured components" if name in ("SGFormer","Loom eager") else "assumption",
                       *c,q,cost(c,q),cost(sc,q)/cost(c,q),qstar])
pd.DataFrame(ledger,columns=["case","component_source","compile_s","first_s","warm_s","peak_mib",
                             "requests","total_s","speedup_vs_sgformer","first_win"]).to_csv(model/"large_lifecycle.csv",index=False)
table("lifecycle_targets","2,097,152 synthetic vertices. Component costs, first winning request and lifetime speedup.",
      "|l|rrr|r|r|rrrrrrr|",r"&\multicolumn{3}{c|}{Time (s)}&Peak&First&\multicolumn{7}{c|}{SGFormer time / row time at $Q$ requests}\\\cline{2-4}\cline{7-13} Path & Build & First & Warm & MiB & win & 1 & 10 & 50 & 100 & 227 & 1k & 2,488",
      rows,"Component anchors use completed GPU runs. Forward-only scenarios divide both first and warm inference by the indicated factor. The joint target also budgets 3 s for build and 4,096 MiB peak allocation.")
# Use the same column positions, marker weights, inset rules and type as Fig. S5.
f=atlas.start(8,"Cost over the lifetime of one layout at 2.10M nodes",1.64)
axes=[atlas.panel(f,[.061+j*.246,.27,.197,.42],title) for j,title in enumerate(
    ["(a)  Total time (s)","(b)  Time / request (s)","(c)  Lifetime speedup"])]
q=np.unique(np.r_[np.geomspace(1,3000,220).astype(int),10,100,1000])
styles=[("SGFormer",atlas.STYLES["Identity"][0],"o","-"),("Loom eager",atlas.ACCENT,"D","-"),
        ("Forward / 2","#536e88","s","--"),("Joint target","#38786A","^","-.")]
for name,col,marker,ls in styles:
    c=cases_gpu[name]
    total=cost(c,q)
    for ax,ys in zip(axes,[total,total/q,cost(sc,q)/total]):
        ax.plot(q,ys,color=col,marker=marker,ls=ls,mfc=col if name=="Loom eager" else "white",
                ms=2.8,mew=.55,lw=1.1,markevery=np.searchsorted(q,[1,10,100,1000,3000]).tolist())
for ax in axes:
    ax.set(xscale="log",xticks=[1,10,100,1000],xticklabels=["1","10","100","1k"],xlabel="Requests per layout")
for ax,ticks in zip(axes[:2],[[10,100,1000,10000],[2,10,100]]):
    ax.set_yscale("log");ax.set_yticks(ticks,[f"{v:,}" for v in ticks]);ax.yaxis.set_minor_locator(NullLocator())
axes[2].set(ylim=(0,3.9),yticks=[0,1,2,3])
cross=crossing(cases_gpu["Forward / 2"])
axes[2].annotate(f"Q = {cross}",(cross,1),xytext=(-7,10),textcoords="offset points",
                 fontsize=6.3,color="#42576d",arrowprops=dict(arrowstyle="-",color="#536e88",lw=.45))
handles=[Line2D([],[],color=c,marker=m,ls=l,ms=3,mfc=c if n=="Loom eager" else "white",lw=1)
         for n,c,m,l in styles]
f.legend(handles,[n for n,*_ in styles],loc="upper center",bbox_to_anchor=(.46,.88),
         ncol=4,fontsize=6.8,handlelength=2,columnspacing=1.1,frameon=False,borderaxespad=0)
labels=["SGFormer","Eager","Fwd / 2","Joint"]
cells=[[f"{cases_gpu[name][3]/1024:.2f}",("ref." if name=="SGFormer" else
        ("∞" if crossing(cases_gpu[name]) is None else str(crossing(cases_gpu[name]))))] for name,*_ in styles]
atlas.table(f,[.762,.27,.226,.42],labels,[("Peak / crossover",2)],["GiB","Q*"],cells,[1.35,1,1],
            first_header="Path")
atlas.caption(f,"Solid curves use measured components. Dashed scenarios change forward time; the joint target also changes build and peak memory.",.028)
f.savefig(figures/"large_lifecycle.pdf");plt.close(f)

p=pd.read_csv(archive/"products_cpu.csv").set_index("phase").wall_seconds
fiedler=p["fiedler_and_gray"]; refine=p["hamming_refinement_and_validation"]
rows=[]
for name,t in [("Build from scratch",fiedler+refine),("Refine existing Fiedler + Gray",refine)]:
    rows.append([name,f"{t:,.2f}",*[f"{t*1000/q:,.1f}" for q in [100,227,1000,2488,10000]],
                 *[f"{int(t/saving)+1:,}" for saving in [.1,.5,1]]])
table("products_threshold","ogbn-products. Savings required on the real graph, relative to the specified starting layout.",
      "|l|r|rrrrr|rrr|",r"&Layout&\multicolumn{5}{c|}{Break-even saving (ms/request) at $Q$}&\multicolumn{3}{c|}{First win at assumed saving}\\\cline{3-10} Investment & cost (s) & 100 & 227 & 1,000 & 2,488 & 10,000 & 100 ms & 500 ms & 1 s",
      rows,"The first row charges the two measured layout stages against a zero-layout-cost alternative. The second charges only refinement against the existing layout. Other preparation is assumed equal; per-request savings remain unmeasured on this graph.")

d=pd.read_csv(archive/"arxiv_models.csv")
cols=["test_accuracy_pct","test_macro_f1_pct","warm_forward_median_ms","warm_forward_p95_ms","warm_peak_allocated_mib"]
methods=["sage","sgformer","loom"]
v={m:[] for m in methods}
for m in methods:
    g=d[d.model==m]; seed=g[g.seed==0].iloc[0]
    v[m]=[g[c].mean() for c in cols[:2]]+[seed[c] for c in cols[2:]]
    setup=seed.host_input_and_artifact_load_ms+seed.device_and_graph_setup_ms
    compile_ms=0 if np.isnan(seed.layout_compile_ms_archived) else seed.layout_compile_ms_archived
    cold=compile_ms+setup+seed.first_forward_ms
    v[m]+=[cold/1000,(cold+99*seed.warm_forward_median_ms)/1000,(cold+999*seed.warm_forward_median_ms)/1000]
goal=[74,54.5,3.30,3.55,200]
cold=180+650+100+4
goal += [cold/1000,(cold+99*goal[2])/1000,(cold+999*goal[2])/1000]
metrics=["Accuracy (\\%)","Macro-F1 (\\%)","Warm P50 (ms)","Warm P95 (ms)","Peak inference (MiB)",
         "Total at 1 request (s)","Total at 100 requests (s)","Total at 1,000 requests (s)"]
rows=[]; targets=[]
for i,(metric,target) in enumerate(zip(metrics,goal)):
    baseline=(max if i<2 else min)(v[m][i] for m in methods[:2])
    advantage=f"+{target-baseline:.2f} pp" if i<2 else f"{baseline/target:.2f}"+r"$\times$"
    rows.append([metric,*[f"{v[m][i]:.2f}" for m in methods],f"{target:.3f}".rstrip("0").rstrip("."),advantage])
    targets.append(["arxiv matched",metric,target,baseline,v["loom"][i]])
table("arxiv_joint","Matched ogbn-arxiv protocol. One hypothetical operating point must meet every budget simultaneously.",
      "|l|rrr|rr|","Measure & GraphSAGE & SGFormer & Loom observed & Joint target & Margin vs. best external",
      rows,r"External best is selected per row. Goals assume 180 ms layout, 650 ms host load, 100 ms device setup and 4 ms first forward. Lifetime uses one build and $Q-1$ warm calls; throughput at saturation is not measured.")
rows=[]
for name,classic,best,actual,target in zip(["A (Schwarz)","B (holes)","C (Bosch)"],[8.82,9.26,11.76],[2.2,2.1,2.1],[2.66,2.16,3.04],[1.76,1.68,1.68]):
    rows.append([name,f"{classic:.2f}",f"{best:.2f}",f"{actual:.2f}",f"{target:.2f}",
                 f"{100*(1-target/actual):.1f}\\%",f"{classic/target:.2f}"+r"$\times$"])
    targets.append(["Laplace2d "+name,"Relative L2 error (%)",target,best,actual])
targets.append(["arxiv node benchmark","Accuracy (%)",74,72.98,72.81])
for domain in ["A","B","C"]:
    for metric,ratio in [("warm P50",1/3),("warm P95",1/3),("peak MiB",.8),("100-call time",.5)]:
        targets.append(["Laplace2d "+domain,metric+" / best matched external",ratio,1,None])
pd.DataFrame(targets,columns=["protocol","metric","design_goal","best_external","current_loom"]).to_csv(model/"joint_targets.csv",index=False)
table("laplace_joint","Laplace2d domain transfer. Relative $L_2$ error (\\%); lower is better.",
      "|l|rrrr|rr|","Domain & MeshGraphNets & SNI+GNOT & Loom observed & Goal & Cut from Loom & Classic / goal",
      rows,"Each goal sets error 20\\% below the lowest reported external mean on that domain. Relative reductions refer to means; paired per-boundary-condition errors would be needed for uncertainty on the difference.")

# Simulate the same service boundary per observed batch before taking quantiles.
rows=[]; preds=[]
for label,g in cases:
    a=g[g["mode"]=="direct"].sort_values("batch"); b=g[g["mode"]=="d2ts"].sort_values("batch")
    t=a.maintenance_ms/2+a.forward_ms/4
    for i,bid in enumerate(a.batch):
        preds.append([label,bid,a.maintenance_ms.iloc[i],a.forward_ms.iloc[i],t.iloc[i],b.e2e_ms.iloc[i]])
    if label in ("Feature","Insert","Delete","Mixed","Low, 128","Uniform, 128","High, 128"):
        rows.append([label,f"{a.e2e_ms.median():.1f}",f"{b.e2e_ms.median():.1f}",
                     f"{t.median():.1f}",f"{t.quantile(.95):.1f}",f"{b.e2e_ms.median()/t.median():.2f}"])
pd.DataFrame(preds,columns=["condition","batch","direct_maint_ms","direct_forward_ms","target_e2e_ms",
                            "external_measured_e2e_ms"]).to_csv(model/"dynamic_budget.csv",index=False)
table("dynamic_budget","Conditional Roman Empire update targets under the measured request boundary.",
      "|l|rr|rr|r|","Batch & Direct P50 & D2TS P50 & Goal P50 & Goal P95 & D2TS / goal",
      rows,r"Milliseconds. Per batch, $T_{\mathrm{goal}}=T_{\mathrm{maint}}/2+T_{\mathrm{forward}}/4$ on the direct path. The final column compares medians. All goal columns require both assumed implementation gains.")

f=plt.figure(figsize=(3.44,1.52))
axes=[atlas.panel(f,[.102,.24,.362,.48],"(a)  Phase ceiling"),
      atlas.panel(f,[.605,.24,.365,.48],"(b)  Reuse budget")]
k=np.geomspace(1,256,100)
for j,col,ls,mk in [(1,grey,":","o"),(4,blue,"--","s"),(16,atlas.ACCENT,"-","D")]:
    axes[0].loglog(k,541.268/k+(579.08-541.268)/j,color=col,ls=ls,marker=mk,markevery=[0,49,99],ms=2.5,lw=1,mfc="white")
axes[0].axhline(3.3,color=teal,ls="--",lw=.8)
axes[0].text(.02,.08,"3.30 ms goal",transform=axes[0].transAxes,color=teal,fontsize=7)
axes[0].set(xlabel="ARCO acceleration (×)",ylabel="Warm ms",xticks=[1,4,16,64,256],
            xticklabels=["1","4","16","64","256"])

q=np.unique(np.geomspace(1,10000,200).astype(int))
sage=d[(d.model=="sage")&(d.seed==0)].iloc[0]
sg_cost=(sage.host_input_and_artifact_load_ms+sage.device_and_graph_setup_ms+
         sage.first_forward_ms+(q-1)*sage.warm_forward_median_ms)
for setup,col,style in [(cold,orange,"-"),(cold-180+9248.8628,blue,"--")]:
    axes[1].semilogx(q,sg_cost/(setup+(q-1)*goal[2]),color=col,ls=style,lw=1.1)
axes[1].axhline(1,color=grey,lw=.6)
axes[1].set(xlabel="Requests per layout",ylabel="GraphSAGE / goal",
            xticks=[1,10,100,1000,10000],xticklabels=["1","10","100","1k","10k"])

f.text(.11,.945,"Other work",fontsize=6.5)
for x,lab,col in [(.31,"1×",grey),(.37,"4×",blue),(.43,"16×",atlas.ACCENT)]:
    f.text(x,.945,lab,color=col,fontsize=6.5)
f.text(.595,.945,"Build",fontsize=6.5)
f.text(.695,.945,"0.18 s",color=orange,fontsize=6.5)
f.text(.83,.945,"9.25 s",color=blue,fontsize=6.5)
f.savefig(figures/"joint_frontiers.pdf");plt.close(f)


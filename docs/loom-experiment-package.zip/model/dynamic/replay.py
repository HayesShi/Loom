"""Replay the same edge stream through two maintained views and the archived Loom predictor."""
import csv
import json
import os
from pathlib import Path
import random
import subprocess
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parent
ROOT = Path(os.getenv("LOOM_PROJECT", HERE.parents[4]))
sys.path[:0] = [str(ROOT / "scripts"), str(ROOT / "external/pytorch_geometric")]
import torch
from profile_loom_vldb_inference import read_workload, normalized_neighbors, Loom


class Backend:
    def __init__(self, mode, initial, x, neighbors):
        self.process = subprocess.Popen(["node", str(HERE / "adapter.mjs"), mode],
                                        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        text=True, encoding="utf-8")
        self.x = x.clone()
        self.cache = neighbors.clone()
        self.exchange(initial)

    def exchange(self, req):
        self.process.stdin.write(json.dumps(req, separators=(",", ":")) + "\n")
        self.process.stdin.flush()
        return json.loads(self.process.stdout.readline())

    def apply(self, req):
        patches = self.exchange(req)
        if req["features"]:
            self.x[req["features"]] *= -1
        rows, ii, jj, products = [], [], [], []
        for i, (dst, terms) in enumerate(patches):
            rows.append(dst)
            for src, degree_product in terms:
                ii.append(i)
                jj.append(src)
                products.append(degree_product)
        if rows:
            index = torch.tensor([ii, jj], dtype=torch.long)
            weights = torch.tensor(products, dtype=self.x.dtype).rsqrt()
            mat = torch.sparse_coo_tensor(index, weights, (len(rows), len(self.x))).coalesce()
            self.cache[rows] = torch.sparse.mm(mat, self.x)
        return len(rows)

    def close(self):
        self.process.stdin.close()
        self.process.wait()


def next_batch(edges, n, kind, rng):
    count = 8 if kind in ("delete", "insert") else 4
    edits = []
    if kind in ("delete", "mixed"):
        for a, b in rng.sample(sorted(edges), count):
            edges.remove((a, b))
            edits.append([a, b, -1])
    if kind in ("insert", "mixed"):
        while sum(m == 1 for _, _, m in edits) < count:
            a, b = sorted(rng.sample(range(n), 2))
            if (a, b) not in edges and [a, b, -1] not in edits:
                edits.append([a, b, 1])
                edges.add((a, b))
    features = rng.sample(range(n), 8 if kind == "feature" else 4) if kind in ("feature","mixed") else []
    return dict(edits=edits, features=features)


def mixed_pool_batch(edges, pool, n, batch, rng):
    eligible = [e for e in sorted(edges) if e[0] in pool or e[1] in pool]
    removed = rng.sample(eligible, batch//2)
    edges.difference_update(removed)
    edits = [[u,v,-1] for u,v in removed]
    anchors = sorted(pool)
    while len(edits) < batch:
        a,b = sorted((rng.choice(anchors), rng.randrange(n)))
        if a != b and (a,b) not in edges and (a,b) not in removed:
            edits.append([a,b,1])
            edges.add((a,b))
    return dict(edits=edits, features=rng.sample(anchors,batch//2))


@torch.inference_mode()
def main():
    torch.set_num_threads(6)
    torch.set_num_interop_threads(1)
    data, layout, weights, meta = read_workload("roman_empire")
    cfg = {k: meta["config"][k] for k in ("dim","heads","blocks","dropout","angle")}
    model = Loom(data.x.shape[1], int(data.y.max())+1, len(data.x), **cfg).eval()
    model.load_state_dict(weights)
    x = data.x
    n = len(x)
    edges = {(u,v) for u,v in data.edge_index.T.tolist() if u < v}
    cache = normalized_neighbors(x, data.edge_index)
    init = dict(n=n, edits=[[u,v,1] for u,v in sorted(edges)], features=[])
    initial_logits = model(x, cache, layout)
    acc = float((initial_logits[data.test_mask].argmax(1)==data.y[data.test_mask]).double().mean()*100)
    assert abs(acc-meta["archived_test_accuracy"]) < 1e-4
    modes = ["direct", "d2ts"]
    backends = {}
    trace, results = [], []
    sweep = "--sweep" in sys.argv
    prefix = "sweep_" if sweep else ""
    degree = torch.bincount(data.edge_index[0],minlength=n).tolist()
    rank = sorted(range(n),key=lambda u:(degree[u],u))
    pools = {"Low":set(rank[:n//4]), "Uniform":set(rank), "High":set(rank[-n//4:])}
    try:
        for mode in modes:
            backends[mode] = Backend(mode, init, x, cache)
        for rep in range(8):
            kinds = ["feature", "insert", "delete", "mixed"]
            if sweep:
                kinds = [(pool,batch) for pool in pools for batch in (8,128)]
            random.Random(1000+rep).shuffle(kinds)
            for i, kind in enumerate(kinds):
                seed = (50100 if sweep else 40100) + len(kinds)*rep+i
                if sweep:
                    pool, batch = kind
                    req = mixed_pool_batch(edges,pools[pool],n,batch,random.Random(seed))
                else:
                    req = next_batch(edges, n, kind, random.Random(seed))
                trace.append(dict(seed=seed, kind=kind, **req))
                # Independent reference recomputes symmetric normalization and the full predictor.
                if req["features"]:
                    x[req["features"]] *= -1
                undirected = torch.tensor(sorted(edges)).T.contiguous()
                oracle_cache = normalized_neighbors(x, torch.cat((undirected, undirected.flip(0)),dim=1))
                oracle = model(x, oracle_cache, layout)
                for order, mode in enumerate(modes if (rep+kinds.index(kind))%2==0 else modes[::-1]):
                    backend = backends[mode]
                    t0 = perf_counter()
                    affected = backend.apply(req)
                    t1 = perf_counter()
                    logits = model(backend.x, backend.cache, layout)
                    t2 = perf_counter()
                    diff = (logits-oracle).abs().max().item()
                    mismatches = int((logits.argmax(1) != oracle.argmax(1)).sum())
                    torch.testing.assert_close(logits, oracle, atol=1e-3, rtol=1e-4)
                    assert mismatches == 0
                    results.append(dict(batch=len(trace), seed=seed, kind=kind if not sweep else pool,
                        edge_batch=len(req["edits"]), mode=mode, order=order,
                        rows=affected, maintenance_ms=(t1-t0)*1000, forward_ms=(t2-t1)*1000,
                        e2e_ms=(t2-t0)*1000, max_logit_delta=diff, label_mismatches=mismatches))
            print("completed block",rep+1,flush=True)
        with (HERE/(prefix+"trials.csv")).open("w",newline="") as f:
            writer=csv.DictWriter(f,fieldnames=list(results[0]))
            writer.writeheader()
            writer.writerows(results)
        (HERE/(prefix+"trace.json")).write_text(json.dumps(trace,indent=2))
        (HERE/(prefix+"meta.json")).write_text(json.dumps(dict(**meta, torch=torch.__version__,threads=6,
            node=subprocess.check_output(["node","--version"],text=True).strip(),d2ts="0.1.8",
            undirected_initial_edges=len(init["edits"]),cpu="Intel Core i9-14900HX",
            frozen_checkpoint_accuracy=acc),indent=2))
    finally:
        for backend in backends.values():
            backend.close()


if __name__=="__main__":
    main()


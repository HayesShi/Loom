"""Per-case Plate quality and lifetime cost at the Roman Empire operating points."""
from pathlib import Path
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]
inputs = root / "archive_inputs" / "plate_cases"
plt.rcParams.update({"font.family":"Times New Roman", "font.size":7.1, "axes.labelpad":1.6,
                     "axes.linewidth":.5, "axes.spines.top":False, "axes.spines.right":False,
                     "xtick.major.size":2.5, "ytick.major.size":2.5, "pdf.fonttype":42})
policies = ["full_compile","reference_reuse"]
selection = pd.read_csv(inputs/"selection.csv").set_index(["layout","seed"])
rows = []
for policy in policies:
    for seed in range(3):
        frame = pd.read_csv(inputs/f"{policy}_{seed}.csv")
        assert len(frame) == 100 and frame.case_id.is_unique
        # The archived score is averaged over nodes. All cases here use the same scoring mask size.
        observed = np.average(frame.state_mse,weights=frame.scored_nodes)
        assert np.isclose(observed,selection.loc[(policy,seed),"test_state_mse"],rtol=1e-5)
        rows.append(frame.assign(policy=policy,seed=seed))
paired = pd.concat(rows).pivot(index=["case_id","seed","scored_nodes"],columns="policy",values="state_mse")
assert len(paired) == 300 and paired.notna().all().all() and (paired>0).all().all()
paired["ratio"] = paired.full_compile / paired.reference_reuse
paired.to_csv(root/"model/paired_mesh_errors.csv")
by_case=paired.ratio.groupby(level="case_id").agg(["min","median","max"])
assert len(by_case)==100 and (paired.groupby(level="case_id").size()==3).all()
p10,median,p90 = by_case["median"].quantile([.1,.5,.9])
fig, ax = plt.subplots(figsize=(3.44,1.37))
fig.subplots_adjust(left=.12,right=.97,bottom=.26,top=.85)
ax.vlines(by_case.index,by_case["min"],by_case["max"],color="#acbcca",lw=.8)
ax.scatter(by_case.index,by_case["median"],s=5,color="#944724",zorder=3)
ax.axhline(1,ls=":",color=".3",lw=.65)
ax.set(yscale="log",xlim=(897,1002),ylim=(.85,135),xticks=[900,925,950,975,999],
       xlabel="Held-out mesh ID",ylabel="MSE ratio (×)")
ax.set_yticks([1,3,10,30,100],["1","3","10","30","100"])
ax.set_title(f"Case medians    P10 {p10:.2f}×     P50 {median:.2f}×     P90 {p90:.2f}×",
             fontsize=7.3,loc="left",pad=2)
fig.savefig(root/"figures/plate_mesh_errors.pdf")
plt.close(fig)

tex=(root/"sections/execution_small.tex").read_text(encoding="utf8")
def numbers(text):
    match=re.search(r"\\(?:best|second)?stat\{([0-9.]+)\}",text)
    return float(match[1] if match else re.search(r"\d+\.\d+",text)[0])

params={}
for line in tex.splitlines():
    fields=[x.strip() for x in line.split("&")]
    if len(fields)!=6 or fields[0] not in {"GraphSAGE","NodeFormer","SGFormer","GraphGPS","Exphormer","Static BF","Indexed","Fused"}:
        continue
    if fields[0]=="Indexed":
        loom_build=1000*numbers(fields[2])
    elif fields[0]=="Fused":
        loom_ms=numbers(fields[4])
    else:
        params[fields[0]]=(1000*numbers(fields[2]),numbers(fields[4]))

q=np.unique(np.geomspace(1,10000,250).round().astype(int))
fig,ax=plt.subplots(figsize=(3.44,1.52))
fig.subplots_adjust(left=.12,right=.98,bottom=.24,top=.76)
records=[]
for (name,(build,warm)),color,style in zip(params.items(),
        ["#375f83","#789f9a","#786e8d","#9c4a24","#547563","#4c5158"],["-","--","-.", "-", "--",":"]):
    ratio=(build+q*warm)/(loom_build+q*loom_ms)
    ax.plot(q,ratio,label=name,color=color,ls=style,lw=1.35 if name=="GraphGPS" else .9)
    records.extend(zip([name]*len(q),q,ratio))
ax.axhline(1,color=".45",ls=":",lw=.55)
ax.set(xscale="log",xlim=(1,10000),ylim=(0,3.35),yticks=[0,1,2,3],
       xlabel="Requests sharing one layout",ylabel="Baseline / Loom (×)")
ax.legend(loc="lower center",bbox_to_anchor=(.52,1.01),ncol=3,frameon=False,fontsize=6.4,
          handlelength=1.6,columnspacing=.72,handletextpad=.32,labelspacing=.08)
fig.savefig(root/"figures/roman_lifetime.pdf")
plt.close(fig)
pd.DataFrame(records,columns=["comparator","requests","projected_speedup"]).to_csv(root/"model/roman_lifetime.csv",index=False)


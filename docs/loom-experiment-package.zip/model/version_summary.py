"""Typeset lifecycle totals from the timed version publications and individual reads."""
from pathlib import Path
import pandas as pd

model=Path(__file__).resolve().parent
d=pd.read_csv(model/"versioned_reads.csv")
rows=[]
for (engine,policy),v in d.groupby(["engine","policy"]):
    first=v[v.read==1]
    assert len(first)==32 and len(v)==128
    initial=first.initial_s.iloc[0]
    total=initial+first.publish_s.sum()+v.read_s.sum()
    one=initial+first.publish_s.sum()+first.read_s.sum()
    rows.append([engine,policy.title(),f"{1000*initial:.1f}",
                 f"{1000*first[first.operation=='feature'].publish_s.median():.2f}",
                 f"{1000*first[first.operation=='insert'].publish_s.median():.2f}",
                 f"{1000*v.read_s.median():.2f}",f"{one:.3f}",f"{total:.3f}",
                 f"{1000*total/128:.2f}",f"{128/total:.1f}"])
lines=[r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}|ll|r|rr|r|rr|rr|}\hline",
r"& & Init. &\multicolumn{2}{c|}{Publish P50 (ms)} & Read &\multicolumn{2}{c|}{Stream cost (s)}&\multicolumn{2}{c|}{4 reads/version}\\\cline{4-5}\cline{7-10}",
r"Engine & Access & ms & Features & Insert & P50 ms & 1 read & 4 reads & ms/read & reads/s\\\hline"]
lines.extend(" & ".join(row)+r"\\" for row in rows)
lines.append(r"\hline\end{tabular*}")
(model.parent/"sections/version_rows.tex").write_text("\n".join(lines)+"\n")
print(rows)
print("Max elementwise discrepancy",d.max_abs.max())
p=pd.read_csv(model.parent/"archive_inputs/plate_stream.csv").set_index("requests")
delta=p.full_compile_s-p.reference_reuse_s
assert delta.iloc[0]<0 and (delta.iloc[1:]>0).all()
print("Plate setup premium ms",-1000*delta.iloc[0],"First lead",delta.iloc[1],
      "throughput",1000/p.iloc[-1],"speedup",p.iloc[-1,0]/p.iloc[-1,1])


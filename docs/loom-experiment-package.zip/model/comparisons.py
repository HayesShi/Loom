"""Derive error ratios and warm-latency targets from the manuscript comparison tables."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
sections = root / "sections"

def entries(tex):
    data = {}
    for line in tex.splitlines():
        if "&" in line:
            vals = re.findall(r"\\(?:best|second)?stat\{([0-9.\-]+)\}\{[0-9.]+\}", line)
            if vals:
                data[line.split("&")[0].strip()] = vals
    return data

def row(cells):
    return " & ".join(cells) + r" \\"

blocks = (sections/"fields.tex").read_text().split(r"\textbf{(b)")
fields, laplace = [entries(b) for b in blocks]
# The published MAE is absent for Loom and Exphormer. Select the common-protocol
# data by column position in the source row, regardless of publication status.
sssp = {}
for line in (sections/"sssp.tex").read_text().splitlines():
    cells = line.split("&")
    if len(cells) == 5:
        match = re.search(r"\\(?:best|second)?stat\{([\d.]+)\}", cells[2])
        if match:
            sssp[cells[0].strip()] = [match[1]]

loom = r"\loomname"
rows = []
def error_row(task, metric, data, col, classic):
    external = min((m for m in data if m != loom), key=lambda m: float(data[m][col]))
    v = data[loom][col]
    c, e = data[classic][col], data[external][col]
    return row([task,metric,classic,c,external,e,v,f"{float(c)/float(v):.2f}",f"{float(e)/float(v):.2f}"])

for classic in ["GCN","GIN"]:
    rows.append(error_row("ECHO-SSSP","MAE",sssp,0,classic))
rows.append(r"\hline")
for col,(name,metric) in enumerate([("Plate","MSE"),("2Dele","score"),("Hodge","MSE")]):
    rows.append(error_row(name,metric,fields,col,"GCN+LN"))
rows.append(r"\hline")
for col,domain in enumerate("ABC"):
    rows.append(error_row("Laplace2d "+domain,r"Rel.~$L_2$ (\%)",laplace,col,"MeshGraphNets"))
(sections/"classic_errors.tex").write_text("\n".join([
    r"\tcap{Prediction error against a classical baseline and the strongest reported external comparator.}",
    r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}|ll|lr|lr|r|rr|}\hline",
    r"& &\multicolumn{2}{c|}{Classical baseline}&\multicolumn{2}{c|}{Best external mean}& Loom &\multicolumn{2}{c|}{Error ratio to Loom}\\",
    r"Task & Metric & Model & Error & Model & Error & Error & Classic/Loom & Best/Loom\\\hline",
    *rows,r"\hline\end{tabular*}",
    r"\tabnote{Ratios divide reported mean errors within each task; above one favors Loom. ECHO uses common-protocol MAE. Sections E and F report dispersion and full comparisons.}"]),encoding="utf8")

rows=[]
for line in (sections/"serving_leaders.tex").read_text().splitlines():
    if line.startswith(("Roman Empire &", "Paris &", "ogbn-arxiv &")):
        cells = [s.strip() for s in line.split("&")]
        baseline = float(re.search(r"[\d.]+",cells[3])[0])
        current = float(re.search(r"[\d.]+",cells[-1])[0])
        rows.append(row([cells[0],cells[1],f"{baseline:.2f}",f"{current:.2f}",
                         f"{baseline/3:.2f}",f"{baseline/5:.2f}",f"{5*current/baseline:.1f}"]))
(sections/"classic_targets.tex").write_text("\n".join([
    r"\tcap{Warm inference targets to exceed the fastest classical comparator at retained Loom accuracy.}",
    r"\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}|ll|rr|rr|r|}\hline",
    r"& &\multicolumn{2}{c|}{Reported latency (ms)}&\multicolumn{2}{c|}{Loom ceiling (ms)}& For $5\times$\\",
    r"Graph & Comparator & Comparator & Loom & $3\times$ & $5\times$ & Required acceleration$^*$\\\hline",
    *rows,r"\hline\end{tabular*}",
    r"\tabnote{$^*$Current Loom time / unrounded $5\times$ ceiling. Targets exclude startup. Roman and Paris use mean inference; arxiv uses warm P50.}"]),encoding="utf8")

